from flask import Flask, request, make_response, redirect, url_for, jsonify,render_template
from flask_mail import Mail, Message
from threading import Thread
import json
import datetime
import uuid
import sys, logging
import os
sys.path.append("/home/best-2/application")
import db_v2
import db_search
import subprocess
import cytoscape_demo


app = Flask(__name__, static_url_path='', template_folder='static')
UPLOAD_FOLDER = '/home/best-2/test/'
app.config['UPLOAD_FOLDER'] = '/home/best-2/test'
app.config.update(
    MAIL_SERVER='mail.cstnet.cn',
    MAIL_PORT=994,
    MAIL_USE_TLS = False,
    MAIL_USE_SSL = True,
    MAIL_USERNAME='bioinfo@psych.ac.cn',
    MAIL_PASSWORD='bioinfo123456',
    MAIL_DEGUB=True
)

logging.basicConfig(level=logging.DEBUG,
                format='%(asctime)s %(levelname)s %(message)s',
                datefmt='%a, %d %b %Y %H:%M:%S',
                filename='info.log',
                filemode='w')

mail = Mail(app)


def send_async_email(app,msg):
    with app.app_context():
        mail.send(msg)

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/run',methods=['POST'])
def run():
    projParm = request.form.to_dict()
    print(projParm)
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
#    projParm = request.get_json()
    jobID=str(uuid.uuid1())[:23]
    jobname=projParm['JobName']
    inputData=projParm['inputData']
    inType=projParm['DType']
    logP=str(projParm['logP'])
    #expData=",".join(projParm['refData'])
    expData=projParm['refData']
    print(type(expData))
    print(expData)
    LD='false'
    LD_data=projParm['dataResourse']
    genePcut=projParm['SNPCutOff']
    gPvalCor=projParm['SNPPvalueMethod']
    clusterPcut=projParm['GeneCutOff']
    cPvalCor=projParm['GenePvalueMethod']
    SNPwin=projParm['SNPwindow']
    email=projParm['email']
#    filedir=projParm['fileData']
#    f=open(filedir, "r")
#    print(type(filedir))
    status="running"
    error="not finished"
    db_v2.insert_sql(jobname, jobID, inType, logP, LD_data, SNPwin, expData, genePcut, gPvalCor, clusterPcut, cPvalCor, email, status, error)
    Num_cluster=str(len(projParm['refData']))
    os.mkdir("/home/best-2/data/"+jobID)
    jobpath="/home/best-2/data/"+jobID+"/"
    
    if "data1" in expData:
        expData=expData+",data9"
    print(expData)
    print("-------------------------------------------------------")
    if "data2" in expData:
        expData=expData+",data10"   
    print(expData)
    print("-------------------------------------------------------")

    if inputData!="":
        f=open("/home/best-2/data/"+jobID+"/inputdata", "w")
        f.write(inputData)
        f.close()
        cmd="sh /home/best-2/application/run_pipeline.sh "+jobpath+"inputdata "+jobpath+" "+Num_cluster+" "+expData+" "+jobID+" "+inType+" "+logP+" "+LD_data+" "+SNPwin+" "+genePcut+" "+gPvalCor+" "+clusterPcut+" "+cPvalCor+" &"
        subprocess.call(cmd, shell=True) 
    elif inputData=="":
        if projParm.get('demo',0)=="demo":
            cmd="cp /home/best-2/demo_data/demo.txt /home/best-2/data/"+jobID+"/inputdata" 
            subprocess.call(cmd, shell=True)
            cmd="sh /home/best-2/application/run_pipeline.sh "+jobpath+"inputdata "+jobpath+" "+Num_cluster+" "+expData+" "+jobID+" "+inType+" "+logP+" "+LD_data+" "+SNPwin+" "+genePcut+" "+gPvalCor+" "+clusterPcut+" "+cPvalCor+" &"
            subprocess.call(cmd, shell=True)
            
            cmd="cp /home/best-2/demo_data/dataset1.png /home/best-2/data/"+jobID+"/."
            subprocess.call(cmd, shell=True)
            cmd="cp /home/best-2/demo_data/dataset3.png /home/best-2/data/"+jobID+"/."
            subprocess.call(cmd, shell=True)
            cmd="cp /home/best-2/demo_data/dataset5.png /home/best-2/data/"+jobID+"/."
            subprocess.call(cmd, shell=True)
    
        else:
            file=request.files['file']
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))
     
            cmd="mv /home/best-2/test/"+file.filename+" /home/best-2/data/"+jobID+"/inputdata"
            subprocess.call(cmd, shell=True)
            cmd="sh /home/best-2/application/run_pipeline.sh "+jobpath+"inputdata "+jobpath+" "+Num_cluster+" "+expData+" "+jobID+" "+inType+" "+logP+" "+LD_data+" "+SNPwin+" "+genePcut+" "+gPvalCor+" "+clusterPcut+" "+cPvalCor+" &"
            subprocess.call(cmd, shell=True) 
########################################################
    if email!="":
        msg = Message('Job Submitted - BEST server',
                      sender=('BEST server', 'bioinfo@psych.ac.cn'),
                      recipients=[email])
        msg.html='<h3>You BEST job (job ID: '+jobID+'; job name: '+jobname+') has been submitted. The results can be retrieved from the following URL http://best.psych.ac.cn/'+jobID
    
        thread=Thread(target=send_async_email, args=[app,msg])
        thread.start()
########################################################
    return json.dumps(jobID)


@app.route('/<jobid>', methods=['POST', 'GET'])
def job(jobid):
    status, jobname, jobid, dataType, logP, refData, LDdata, gPcut, gPcor, cPcut, cPcor, SNPwin, begin, ending=db_v2.search_sql_all(jobid)
    if status=='finished':
        status='done'
    else:
        print(status)
    
    resultDict = {
        "status":status,
        'jobName':jobname,
        'jobID':jobid,
        'DType':dataType,
        'logP':str(logP),
        'refData':refData,
        'dataResourse':LDdata,
        'SNPPvalueMethod':gPcor,
        'SNPCutOff':gPcut,
        'GenePvalueMethod':cPcor,
        'GeneCutOff':cPcut,
        'SNPwindow':SNPwin,
        'jobStarted':str(begin),
        'jobFinished':str(ending),}

    Results_path='/home/best-2/data/'+jobid+"/"
    if os.path.isfile(Results_path+"all_result.tar"):
        Downloadfile='.'+Results_path[12:]+"all_result.tar"
    else:
        Downloadfile=[]
        print("no result file")

    if os.path.isfile(Results_path+"enrich.png"):
        venn_plotfile='.'+Results_path[12:]+"enrich.png"
    else:
        venn_plotfile=[]
        print("no venn file")

    resultDict['Download']=Downloadfile
    resultDict['venn']=venn_plotfile

    tab1_list=[]
    tab2_list=[]
    for root,dirs,files in os.walk(Results_path):
        gene_celltype_data=root+"/geneset_celltype.png"
        if os.path.isfile(gene_celltype_data):
            tab1_list.append("geneset celltype")
            tab1_list.append('.'+gene_celltype_data[12:])
        for name in dirs:
            if name[:11] == "clusterdata":
                if name=="clusterdata1":
                    title="RNA-seq Data from Brainspan"
                elif name=="clusterdata2":
                    title="Microaray data from Allen Brain altas"
                elif name=="clusterdata3":
                    title="Microaray data from Brainspan"
                elif name=="clusterdata4":
                    title="RNA-seq data from He Z et al, 2014"
                elif name=="clusterdata5":
                    title="RNA-seq data from Xu C et al, 2018"
                elif name=="clusterdata6":
                    title="RNA-seq data from He Z et al, 2017"
                elif name=="clusterdata7":
                    title="RNA-seq data from GTEx"
                elif name=="clusterdata8":
                    title="RNA-seq data from Lister R et al, 2013"
                elif name=="clusterdata9":
                    title="RNA-seq Data from Brainspan(25x9)"
                elif name=="clusterdata10":
                    title="Microaray data from Allen Brain altas(51x2)"

                expression_data=root+name+"/Results/expression.png"
                if os.path.isfile(expression_data):
                    tab1_list.append(title)
                    tab1_list.append('.'+expression_data[12:])

                man_data=root+name+"/Results/manhattan.png"
                if os.path.isfile(man_data):
                    tab2_list.append(title)
                    tab2_list.append('.'+man_data[12:])
                else:
                    tab2_list.append(title)
                    tab2_list.append("NA")

                man_bar_data=root+name+"/Results/manhattan_bar.png"
                if os.path.isfile(man_bar_data):
                    tab2_list.append('.'+man_bar_data[12:])
                else:
                    tab2_list.append("NA")

    resultDict['tab1']=tab1_list
    resultDict['tab2']=tab2_list

    tab4_list=[]
    network_data1="/home/best-2/data/"+jobid+"/clusterdata1/Results/all.top20"
    network_data2="/home/best-2/data/"+jobid+"/clusterdata2/Results/all.top20"
    network_data3="/home/best-2/data/"+jobid+"/clusterdata3/Results/all.top20"
    network_data5="/home/best-2/data/"+jobid+"/clusterdata5/Results/all.top20"
    network_data7="/home/best-2/data/"+jobid+"/clusterdata7/Results/all.top20"
    network_data9="/home/best-2/data/"+jobid+"/clusterdata9/Results/all.top20"
    network_data10="/home/best-2/data/"+jobid+"/clusterdata10/Results/all.top20"
    if os.path.isfile(network_data1):
        tab4_list.append("RNA-seq Data from Brainspan")
        tab4_list.append(cytoscape_demo.getJsonFile(network_data1))
    if os.path.isfile(network_data2):
        tab4_list.append("Microaray data from Allen Brain altas")
        tab4_list.append(cytoscape_demo.getJsonFile(network_data2))
    if os.path.isfile(network_data3):
        tab4_list.append("Microaray data from Brainspan")
        tab4_list.append(cytoscape_demo.getJsonFile(network_data3))
    if os.path.isfile(network_data5):
        tab4_list.append("RNA-seq data from Xu C et al, 2018")
        tab4_list.append(cytoscape_demo.getJsonFile(network_data5))
    if os.path.isfile(network_data7):
        tab4_list.append("RNA-seq data from GTEx")
        tab4_list.append(cytoscape_demo.getJsonFile(network_data7))
    if os.path.isfile(network_data9):
        tab4_list.append("RNA-seq Data from Brainspan(25x9)")
        tab4_list.append(cytoscape_demo.getJsonFile(network_data9))
    if os.path.isfile(network_data10):
        tab4_list.append("Microaray data from Allen Brain altas(51x2)")
        tab4_list.append(cytoscape_demo.getJsonFile(network_data10))
    resultDict['tab4']=tab4_list

##########################
    tab3_list=[]
    for root,dirs,files in os.walk(Results_path):
        for name in dirs:
            if name[:11] == "clusterdata":
                if name=="clusterdata1":
                    title="RNA-seq Data from Brainspan"
                elif name=="clusterdata2":
                    title="Microaray data from Allen Brain altas"
                elif name=="clusterdata3":
                    title="Microaray data from Brainspan"
                elif name=="clusterdata4":
                    title="RNA-seq data from He Z et al, 2014"
                elif name=="clusterdata5":
                    title="RNA-seq data from Xu C et al, 2018"
                elif name=="clusterdata6":
                    title="RNA-seq data from He Z et al, 2017"
                elif name=="clusterdata7":
                    title="RNA-seq data from GTEx"
                elif name=="clusterdata8":
                    title="RNA-seq data from Lister R et al, 2013"
                elif name=="clusterdata9":
                    title="RNA-seq Data from Brainspan(25x9)"
                elif name=="clusterdata10":
                    title="Microaray data from Allen Brain altas(51x2)"

                tab3_list.append(title)
                cluster_list=[]
                celltype_data=root+name+"/Results/celltype.png"
                if os.path.isfile(celltype_data):
                    cluster_list.append("celltype enrichment")
                    cluster_list.append('.'+celltype_data[12:])

                celltype_data_withclustering=root+name+"/Results/celltype_withclustering.png"
                if os.path.isfile(celltype_data_withclustering):
                    cluster_list.append("celltype enrichment with clustering")
                    cluster_list.append('.'+celltype_data_withclustering[12:])

                files_2=[]
                for root_1,dirs_1,files_1 in os.walk(root+name+"/Results/"):
                     for filename in files_1:
                         if filename[:2]=='N_' and filename[-3:]=='png':
                             files_2.append(filename)
                     print(files_2)
                     files_2.sort(key=lambda x:int(x[9:-12]))
                     for filename in files_2:
                         cluster_list.append(filename[:-12])
                         cluster_list.append('.'+root_1[12:]+filename)
                     
                resultDict[title]=cluster_list
    resultDict['tab3']=tab3_list
    
    if request.method == 'POST':
        return json.dumps(resultDict)

    if request.method == 'GET':
        if resultDict.get('status') != 'done':
            return render_template('remain.html')
        else:
            context = parseResult(resultDict)
            return render_template('job.html',**context)

def TabFunc(dataArray, tabNum):
    itemsArray = list()
    contentArray = list()
    print(len(dataArray))
    print(type(len(dataArray)))
    for iIndex in range(int(len(dataArray) / 2)):
        if iIndex == 0:
            hid = '#' + tabNum
            itemsArray.append(
                '''<li class="active"><a href={hid} aria-controls={data} role="tab" role="tab" data-toggle="tab">{data}</a></li>'''.
                format(hid=hid, data=dataArray[0]))
            contentArray.append(
                '''<div class="tab-pane active" id={tabNum}><img class='img-responsive' src={data}/></div>'''.
                format(tabNum=tabNum, data=dataArray[1]))
        else:
            hid = '#' + tabNum + str(2 * iIndex)
            itemsArray.append(
                '''<li><a href={hid} aria-controls={data} role="tab" data-toggle="tab">{data}</a></li>'''.
                format(hid=hid, data=dataArray[2 * iIndex]))
            contentArray.append(
                '''<div class="tab-pane" id={tabnum}><img class='img-responsive' src={data}/></div>'''.
                format(
                    tabnum=tabNum + str(2 * iIndex),
                    data=dataArray[2 * iIndex + 1]))
    return itemsArray, contentArray

def Tab2Func(dataArray, items):
    itemsArray = list()
    contentArray = list()
    for iIndex in range(len(dataArray)):
        if iIndex == 0:
            itemsArray.append('''<p>{data}</p>'''.format(data=dataArray[0]))
            item = items[dataArray[0]]
            for kIndex in range(int(len(item) / 2)):
                if kIndex == 0:
                    itemsArray.append(
                        '''<li class="active"><a href="#tab2" aria-controls={item0} role="tab" role="tab" data-toggle="tab">{item0}</a></li>'''.
                        format(item0=item[0]))
                    contentArray.append(
                        '''<div class="tab-pane active" id='tab2'><img class='img-responsive' src={item1}/></div>'''.
                        format(item1=item[1]))
                else:
                    hid = '#tab2-' + str(iIndex) + '-' + str(kIndex)
                    itemsArray.append(
                        '''<li><a href={hid} aria-controls={item2K} role="tab" role="tab" data-toggle="tab">{item2K}</a></li>'''.
                        format(hid=hid, item2K=item[2 * kIndex]))
                    contentArray.append(
                        '''<div class="tab-pane" id={tabK}><img class='img-responsive' src={item2K1}/></div>'''.
                        format(
                            tabK='tab2-' + str(iIndex) + '-' + str(kIndex),
                            item2K1=item[2 * kIndex + 1]))
        else:
            item = items[dataArray[iIndex]]
            itemsArray.append(
                '''<p>{data}</p>'''.format(data=dataArray[iIndex]))
            for kIndex in range(int(len(item) / 2)):
                hid = '#tab2-' + str(iIndex) + '-' + str(kIndex)
                itemsArray.append(
                    '''<li><a href={hid} aria-controls={item2K} role="tab" role="tab" data-toggle="tab">{item2K}</a></li>'''.
                    format(hid=hid, item2K=item[2 * kIndex]))
                contentArray.append(
                    '''<div class="tab-pane" id={tabN}><img class='img-responsive' src={item2K1}/></div>'''.
                    format(
                        tabN='tab2-' + str(iIndex) + '-' + str(kIndex),
                        item2K1=item[2 * kIndex + 1]))
    return itemsArray, contentArray

def parseResult(resultDict):
    context = dict()
    context['jobName'] = resultDict['jobName']
    context['jobID'] = resultDict['jobID']

    if resultDict['DType'] =='SNPandP':
        context['Dtype'] = 'SNP list (with p-value)'
    elif resultDict['DType'] =='GENEandP':
        context['Dtype'] = 'Gene list (with p-value)'
    elif resultDict['DType'] =='SNPList':
        context['Dtype'] = 'SNP list (without p-value)'
    elif resultDict['DType'] =='GeneList':
        context['Dtype'] = 'Gene list (without p-value)'


    if resultDict['logP'] =='true':
        context['logP'] = 'Y'
    elif resultDict['logP'] =='false':
        context['logP'] = 'N'

    if resultDict['SNPwindow'] == '0':
        context['snpWindow'] = "within gene"
    elif resultDict['SNPwindow'] == '10':
        context['snpWindow'] = '10 kb upstream and downstream of gene'
    elif resultDict['SNPwindow'] == '50':
        context['snpWindow'] = '50 kb upstream and downstream of gene'


    refDatadic = {'data1':'1.RNA-seq Data from Brainspan (with co-expression clusters)',
                  'data2':'2.Microaray data from Allen Brain altas (with co-expression clusters)',
                  'data3':'3.Microaray data from Brainspan (with co-expression clusters)',
                  'data4':'4.RNA-seq data from He Z et al, 2014',
                  'data5':'5.RNA-seq data from Xu C et al, 2018 (with co-expression clusters)',
                  'data6':'6.RNA-seq data from He Z et al, 2017',
                  'data7':'7.RNA-seq data from GTEx (with co-expression clusters)',
                  'data8':'8.RNA-seq data from Lister R et al, 2013'}

    refDataArray = resultDict['refData'].split(',')
    context['refDataArray'] = list()
    for item in refDataArray:
        context['refDataArray'].append('''<p>{item}</p>'''.format(item=refDatadic[item]))


    if resultDict.get('venn'):
        venn='''<p><img class='img-responsive' src={venn}/></p>'''.format(
                venn=resultDict.get('venn'))
        context['venn'] = venn

    
    context['dataResourse'] = resultDict['dataResourse']
    context['SNPPvalueMethod'] = resultDict['SNPPvalueMethod']
    context['SNPCutOff'] = resultDict['SNPCutOff']
    context['GenePvalueMethod'] = resultDict['GenePvalueMethod']
    context['GeneCutOff'] = resultDict['GeneCutOff']
    context['jobStarted'] = resultDict['jobStarted']
    context['jobFinished'] = resultDict['jobFinished']
    context['Download'] = resultDict['Download']
    tab1ItemsArray, tab1ContentArray = TabFunc(resultDict['tab1'], 'tab1')
    context['tab1ItemsArray'] = tab1ItemsArray
    context['tab1ContentArray'] = tab1ContentArray
    tab2ItemsArray, tab2ContentArray = Tab2Func(resultDict['tab2'], resultDict)
    context['tab2ItemsArray'] = tab2ItemsArray
    context['tab2ContentArray'] = tab2ContentArray
    tab3ItemsArray, tab3ContentArray = TabFunc(resultDict['tab3'], 'tab3')
    context['tab3ItemsArray'] = tab3ItemsArray
    context['tab3ContentArray'] = tab3ContentArray
    tab4ItemsArray, tab4ContentArray = TabFunc(resultDict['tab4'], 'tab4')
    context['tab4ItemsArray'] = tab4ItemsArray
    context['tab4ContentArray'] = tab4ContentArray
    return context

if __name__ == '__main__':
    app.debug = True
    app.run(port=8081,host="0.0.0.0")
