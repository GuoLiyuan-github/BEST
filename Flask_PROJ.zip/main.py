from flask import Flask, request, make_response, redirect, url_for, jsonify, render_template
import json
import datetime
import os

app = Flask(__name__, static_url_path='', template_folder='static')

UPLOAD_FOLDER = './updata/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# app.jinja_env.variable_start_string = '{{ '
# app.jinja_env.variable_end_string = ' }}'


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/run', methods=['POST'])
def run():
    #print request.json
    projParm = request.form.to_dict()
    print projParm
    #if 
    #file = request.files['file']
    #file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))
    #projParm = request.get_json()
    #print type(projParm['JobName'])
    #print projParm
    return json.dumps('123')


@app.route('/job/<jobid>', methods=['POST'])
def job(jobid):
    resultDict = {
        "status":
        'done',
        'jobName':
        'test1',
        'jobID':
        '123',
        'DType':
        'SNPandP',
        'logP':
        True,
        'refData':
        'data1,data2,data3',
        'dataResourse':
        'eur',
        'SNPPvalueMethod':
        'fdr_by',
        'SNPCutOff':
        '0.05',
        'GenePvalueMethod':
        'fdr_by',
        'GeneCutOff':
        '0.01',
        'SNPwindow':
        '10',
        'jobStarted':
        '9:08:05',
        'jobFinished':
        '9:10:06',
        'venn':
        './data/92dfa6d8-0267-11e9-a506-20040ff01498/venn.png',
        'tab3': ['cytoscape', './images/homepage/website-testfig1.png'],
        'tab4': [
            'manhatten',
            './data/92dfa6d8-0267-11e9-a506-20040ff01498/manhatten.png'
        ],
        'tab1': [
            'data1',
            '/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png',
            'data3 expression',
            '/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png',
            "clusterdata1_celltype",
            "/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/celltype.png",
            "clusterdata3_celltype",
            "/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/celltype.png"
        ],
        'tab2': ['clusterdata1', 'clusterdata3'],
        'clusterdata1': [
            'N_paleturquoise',
            '/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_paleturquoise.txt.exp.png',
            'N_lightcyan1',
            '/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_lightcyan1.txt.exp.png'
        ],
        'clusterdata3': [
            'N_blue',
            '/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_blue.txt.exp.png',
            'N_darkgrey',
            '/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_darkgrey.txt.exp.png'
        ]
    }
    if request.method == 'POST':
        # print request.get_json().get('jobID')
        # print request.get_json()
        return json.dumps(resultDict)

    # if request.method == 'GET':
    #     app.send_static_file('job.html')
    #     if resultDict.get('status') != 'done':
    #         return json.dumps('null')
    #     else:
    #         return json.dumps(resultDict)


@app.route('/<jobid>', methods=['POST', 'GET'])
def result(jobid):
    resultDict = {
        "status":
        'done',
        'jobName':
        'test1',
        'jobID':
        '123',
        'DType':
        'Plink',
        'logP':
        True,
        'refData':
        'data1,data2,data3',
        'dataResourse':
        'eur',
        'SNPPvalueMethod':
        'fdr_by',
        'SNPCutOff':
        '0.05',
        'GenePvalueMethod':
        'fdr_by',
        'GeneCutOff':
        '0.01',
        'SNPwindow':
        '10',
        'jobStarted':
        '9:08:05',
        'jobFinished':
        '9:10:06',
        'venn':
        './images/homepage/Fig2.png',
        'Download':
        'dddddddddd',
        # 'tab4':[],
        'tab4': ['cytoscape1',{"nodes": [{"data": {"id": "ARHGEF10L0", "name": "ARHGEF10L"}}, {"data": {"id": "CBLN10", "name": "CBLN1"}}, {"data": {"id": "CRTAM0", "name": "CRTAM"}}, {"data": {"id": "IRF60", "name": "IRF6"}}, {"data": {"id": "RPS6KA10", "name": "RPS6KA1"}}, {"data": {"id": "AVPR20", "name": "AVPR2"}}, {"data": {"id": "RHBG0", "name": "RHBG"}}, {"data": {"id": "CCNJL0", "name": "CCNJL"}}, {"data": {"id": "MAP3K120", "name": "MAP3K12"}}, {"data": {"id": "CBLN30", "name": "CBLN3"}}, {"data": {"id": "PPFIA40", "name": "PPFIA4"}}, {"data": {"id": "KCTD140", "name": "KCTD14"}}, {"data": {"id": "LETM20", "name": "LETM2"}}, {"data": {"id": "MTCL10", "name": "MTCL1"}}, {"data": {"id": "CDC42BPG0", "name": "CDC42BPG"}}, {"data": {"id": "PDZK10", "name": "PDZK1"}}, {"data": {"id": "EPS8L20", "name": "EPS8L2"}}, {"data": {"id": "ACP70", "name": "ACP7"}}, {"data": {"id": "C20orf2040", "name": "C20orf204"}}, {"data": {"id": "PISD0", "name": "PISD"}}], "edges": [{"data": {"source": "ARHGEF10L0", "target": "CBLN10", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "CRTAM0", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "IRF60", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "RPS6KA10", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "LETM20", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "CRTAM0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "IRF60", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "RPS6KA10", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "LETM20", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "IRF60", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "RPS6KA10", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "LETM20", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "IRF60", "target": "RPS6KA10", "relationship": ""}}, {"data": {"source": "IRF60", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "IRF60", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "IRF60", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "IRF60", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "IRF60", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "IRF60", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "IRF60", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "IRF60", "target": "LETM20", "relationship": ""}}, {"data": {"source": "IRF60", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "IRF60", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "IRF60", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "IRF60", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "IRF60", "target": "ACP70", "relationship": ""}}, {"data": {"source": "IRF60", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "IRF60", "target": "PISD0", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "LETM20", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "ACP70", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "PISD0", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "LETM20", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "ACP70", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "PISD0", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "LETM20", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "LETM20", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "LETM20", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "ACP70", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "LETM20", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "PISD0", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "LETM20", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "ACP70", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "PISD0", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "LETM20", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "ACP70", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "PISD0", "relationship": ""}}, {"data": {"source": "LETM20", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "LETM20", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "LETM20", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "LETM20", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "LETM20", "target": "ACP70", "relationship": ""}}, {"data": {"source": "LETM20", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "LETM20", "target": "PISD0", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "ACP70", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "PDZK10", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "PDZK10", "target": "ACP70", "relationship": ""}}, {"data": {"source": "PDZK10", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "PDZK10", "target": "PISD0", "relationship": ""}}, {"data": {"source": "EPS8L20", "target": "ACP70", "relationship": ""}}, {"data": {"source": "EPS8L20", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "EPS8L20", "target": "PISD0", "relationship": ""}}, {"data": {"source": "ACP70", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "ACP70", "target": "PISD0", "relationship": ""}}, {"data": {"source": "C20orf2040", "target": "PISD0", "relationship": ""}}]},'cytoscape2',{"nodes": [{"data": {"id": "ARHGEF10L0", "name": "ARHGEF10L"}}, {"data": {"id": "CBLN10", "name": "CBLN1"}}, {"data": {"id": "CRTAM0", "name": "CRTAM"}}, {"data": {"id": "IRF60", "name": "IRF6"}}, {"data": {"id": "RPS6KA10", "name": "RPS6KA1"}}, {"data": {"id": "AVPR20", "name": "AVPR2"}}, {"data": {"id": "RHBG0", "name": "RHBG"}}, {"data": {"id": "CCNJL0", "name": "CCNJL"}}, {"data": {"id": "MAP3K120", "name": "MAP3K12"}}, {"data": {"id": "CBLN30", "name": "CBLN3"}}, {"data": {"id": "PPFIA40", "name": "PPFIA4"}}, {"data": {"id": "KCTD140", "name": "KCTD14"}}, {"data": {"id": "LETM20", "name": "LETM2"}}, {"data": {"id": "MTCL10", "name": "MTCL1"}}, {"data": {"id": "CDC42BPG0", "name": "CDC42BPG"}}, {"data": {"id": "PDZK10", "name": "PDZK1"}}, {"data": {"id": "EPS8L20", "name": "EPS8L2"}}, {"data": {"id": "ACP70", "name": "ACP7"}}, {"data": {"id": "C20orf2040", "name": "C20orf204"}}, {"data": {"id": "PISD0", "name": "PISD"}}, {"data": {"id": "SEMA3B1", "name": "SEMA3B"}}, {"data": {"id": "ERBB31", "name": "ERBB3"}}, {"data": {"id": "SLCO1A21", "name": "SLCO1A2"}}, {"data": {"id": "TF1", "name": "TF"}}, {"data": {"id": "SGK21", "name": "SGK2"}}, {"data": {"id": "FA2H1", "name": "FA2H"}}, {"data": {"id": "RTKN1", "name": "RTKN"}}, {"data": {"id": "EFHD11", "name": "EFHD1"}}, {"data": {"id": "LDB31", "name": "LDB3"}}, {"data": {"id": "PLP11", "name": "PLP1"}}, {"data": {"id": "MOCS11", "name": "MOCS1"}}, {"data": {"id": "MYRF1", "name": "MYRF"}}, {"data": {"id": "GLTP1", "name": "GLTP"}}, {"data": {"id": "TTYH21", "name": "TTYH2"}}, {"data": {"id": "DAAM21", "name": "DAAM2"}}, {"data": {"id": "KIAA17551", "name": "KIAA1755"}}, {"data": {"id": "RHBDL21", "name": "RHBDL2"}}, {"data": {"id": "FAXDC21", "name": "FAXDC2"}}, {"data": {"id": "PLA2G161", "name": "PLA2G16"}}, {"data": {"id": "KIF13B1", "name": "KIF13B"}}], "edges": [{"data": {"source": "ARHGEF10L0", "target": "CBLN10", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "CRTAM0", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "IRF60", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "RPS6KA10", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "LETM20", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "ARHGEF10L0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "CRTAM0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "IRF60", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "RPS6KA10", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "LETM20", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CBLN10", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "IRF60", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "RPS6KA10", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "LETM20", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CRTAM0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "IRF60", "target": "RPS6KA10", "relationship": ""}}, {"data": {"source": "IRF60", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "IRF60", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "IRF60", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "IRF60", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "IRF60", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "IRF60", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "IRF60", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "IRF60", "target": "LETM20", "relationship": ""}}, {"data": {"source": "IRF60", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "IRF60", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "IRF60", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "IRF60", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "IRF60", "target": "ACP70", "relationship": ""}}, {"data": {"source": "IRF60", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "IRF60", "target": "PISD0", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "AVPR20", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "LETM20", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "ACP70", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "RPS6KA10", "target": "PISD0", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "RHBG0", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "LETM20", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "ACP70", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "AVPR20", "target": "PISD0", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "CCNJL0", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "LETM20", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "RHBG0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "MAP3K120", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "LETM20", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CCNJL0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "CBLN30", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "LETM20", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "ACP70", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "MAP3K120", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "PPFIA40", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "LETM20", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CBLN30", "target": "PISD0", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "KCTD140", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "LETM20", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "ACP70", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "PPFIA40", "target": "PISD0", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "LETM20", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "ACP70", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "KCTD140", "target": "PISD0", "relationship": ""}}, {"data": {"source": "LETM20", "target": "MTCL10", "relationship": ""}}, {"data": {"source": "LETM20", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "LETM20", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "LETM20", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "LETM20", "target": "ACP70", "relationship": ""}}, {"data": {"source": "LETM20", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "LETM20", "target": "PISD0", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "CDC42BPG0", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "ACP70", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "MTCL10", "target": "PISD0", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "PDZK10", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "ACP70", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "CDC42BPG0", "target": "PISD0", "relationship": ""}}, {"data": {"source": "PDZK10", "target": "EPS8L20", "relationship": ""}}, {"data": {"source": "PDZK10", "target": "ACP70", "relationship": ""}}, {"data": {"source": "PDZK10", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "PDZK10", "target": "PISD0", "relationship": ""}}, {"data": {"source": "EPS8L20", "target": "ACP70", "relationship": ""}}, {"data": {"source": "EPS8L20", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "EPS8L20", "target": "PISD0", "relationship": ""}}, {"data": {"source": "ACP70", "target": "C20orf2040", "relationship": ""}}, {"data": {"source": "ACP70", "target": "PISD0", "relationship": ""}}, {"data": {"source": "C20orf2040", "target": "PISD0", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "ERBB31", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "SLCO1A21", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "TF1", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "SGK21", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "FA2H1", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "RTKN1", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "EFHD11", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "LDB31", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "PLP11", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "SEMA3B1", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "SLCO1A21", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "TF1", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "SGK21", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "FA2H1", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "RTKN1", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "EFHD11", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "LDB31", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "PLP11", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "ERBB31", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "TF1", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "SGK21", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "FA2H1", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "RTKN1", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "EFHD11", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "LDB31", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "PLP11", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "SLCO1A21", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "TF1", "target": "SGK21", "relationship": ""}}, {"data": {"source": "TF1", "target": "FA2H1", "relationship": ""}}, {"data": {"source": "TF1", "target": "RTKN1", "relationship": ""}}, {"data": {"source": "TF1", "target": "EFHD11", "relationship": ""}}, {"data": {"source": "TF1", "target": "LDB31", "relationship": ""}}, {"data": {"source": "TF1", "target": "PLP11", "relationship": ""}}, {"data": {"source": "TF1", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "TF1", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "TF1", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "TF1", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "TF1", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "TF1", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "TF1", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "TF1", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "TF1", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "TF1", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "SGK21", "target": "FA2H1", "relationship": ""}}, {"data": {"source": "SGK21", "target": "RTKN1", "relationship": ""}}, {"data": {"source": "SGK21", "target": "EFHD11", "relationship": ""}}, {"data": {"source": "SGK21", "target": "LDB31", "relationship": ""}}, {"data": {"source": "SGK21", "target": "PLP11", "relationship": ""}}, {"data": {"source": "SGK21", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "SGK21", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "SGK21", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "SGK21", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "SGK21", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "SGK21", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "SGK21", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "SGK21", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "SGK21", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "SGK21", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "RTKN1", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "EFHD11", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "LDB31", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "PLP11", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "FA2H1", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "EFHD11", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "LDB31", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "PLP11", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "RTKN1", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "LDB31", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "PLP11", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "EFHD11", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "LDB31", "target": "PLP11", "relationship": ""}}, {"data": {"source": "LDB31", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "LDB31", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "LDB31", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "LDB31", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "LDB31", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "LDB31", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "LDB31", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "LDB31", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "LDB31", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "LDB31", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "PLP11", "target": "MOCS11", "relationship": ""}}, {"data": {"source": "PLP11", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "PLP11", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "PLP11", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "PLP11", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "PLP11", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "PLP11", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "PLP11", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "PLP11", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "PLP11", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "MOCS11", "target": "MYRF1", "relationship": ""}}, {"data": {"source": "MOCS11", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "MOCS11", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "MOCS11", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "MOCS11", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "MOCS11", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "MOCS11", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "MOCS11", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "MOCS11", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "MYRF1", "target": "GLTP1", "relationship": ""}}, {"data": {"source": "MYRF1", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "MYRF1", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "MYRF1", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "MYRF1", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "MYRF1", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "MYRF1", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "MYRF1", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "GLTP1", "target": "TTYH21", "relationship": ""}}, {"data": {"source": "GLTP1", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "GLTP1", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "GLTP1", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "GLTP1", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "GLTP1", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "GLTP1", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "TTYH21", "target": "DAAM21", "relationship": ""}}, {"data": {"source": "TTYH21", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "TTYH21", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "TTYH21", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "TTYH21", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "TTYH21", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "DAAM21", "target": "KIAA17551", "relationship": ""}}, {"data": {"source": "DAAM21", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "DAAM21", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "DAAM21", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "DAAM21", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "KIAA17551", "target": "RHBDL21", "relationship": ""}}, {"data": {"source": "KIAA17551", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "KIAA17551", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "KIAA17551", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "RHBDL21", "target": "FAXDC21", "relationship": ""}}, {"data": {"source": "RHBDL21", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "RHBDL21", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "FAXDC21", "target": "PLA2G161", "relationship": ""}}, {"data": {"source": "FAXDC21", "target": "KIF13B1", "relationship": ""}}, {"data": {"source": "PLA2G161", "target": "KIF13B1", "relationship": ""}}]}],
        'tab10': [
            'manhatten1',
            './images/homepage/Fig1.png','./images/homepage/Fig2.png','manhatten2','./images/homepage/Fig3.png','NA','manhatten3','NA','./images/homepage/Fig4.png'
        ],
        'tab2':[],
        'tab1': [
            'data1',
            '/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png',
            'data3 expression',
            '/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png',
            "clusterdata1_celltype",
            "/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/celltype.png",
            "clusterdata3_celltype",
            "/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/celltype.png"
        ],
        'tab3': ['clusterdata1','clusterdata3'],
        'clusterdata1': [
            'N_paleturquoise',
            './images/homepage/Fig1.png',
            'N_lightcyan1',
            './images/homepage/Fig2.png'
        ],
        'clusterdata3': [
            'N_blue',
            './images/homepage/Fig3.png',
            'N_darkgrey',
            './images/homepage/Fig4.png'
        ]
    }
    if request.method == 'POST':
        # print request.get_json().get('jobID')
        # print request.get_json()
        return json.dumps(resultDict)

    if request.method == 'GET':
        if resultDict.get('status') != 'done':
            return render_template('remain.html')
        else:
            context = parseResult(resultDict)
            return render_template('job.html',**context)


def TabFunc(dataArray, tabNum):
    itemsArray = list()
    contentArray = list()
    for iIndex in range(len(dataArray) / 2):
        if iIndex == 0:
            hid = '#' + tabNum
            itemsArray.append(
                '''<li class="active"><a href={hid} aria-controls={data} role="tab" role="tab" data-toggle="tab">{data}</a></li>'''.
                format(hid=hid, data=dataArray[0]))
            contentArray.append(
                '''<div class="tab-pane active" id={tabNum}><img class='img-responsive' src={data}/></div>'''.
                format(tabNum=tabNum, data=dataArray[1]))
        else:
            hid = '#' + tabNum + str(2 * iIndex)
            itemsArray.append(
                '''<li><a href={hid} aria-controls={data} role="tab" data-toggle="tab">{data}</a></li>'''.
                format(hid=hid, data=dataArray[2 * iIndex]))
            contentArray.append(
                '''<div class="tab-pane" id={tabnum}><img class='img-responsive' src={data}/></div>'''.
                format(
                    tabnum=tabNum + str(2 * iIndex),
                    data=dataArray[2 * iIndex + 1]))
    return itemsArray, contentArray


def Tab2Func(dataArray):
    itemsArray = list()
    contentArray = list()
    for i in xrange(len(dataArray)/3):
        if i == 0 :
            itemsArray.append('''<li  class="active"><a href='#tab2' aria-controls={data} role="tab" role="tab" data-toggle="tab">{data}</a></li>'''.format(data = dataArray[0]))
            if dataArray[1] =='NA' and dataArray[2]!='NA':
                contentArray.append('''<div class="tab-pane active" id='tab2'><p>Can't generate Manhattan plot. Possible reasons:</p> <p>1) the input dataset is not include P value;</p><p>2) the input dataset is not distributed in any co-expression clusters;</p><p>3) the selected reference dataset is not include information of co-expression cluster.</p><img  class='img-responsive' src={data}/></div>'''.format(data = dataArray[2]))
            elif dataArray[1] !='NA' and dataArray[2] =='NA':
                contentArray.append('''<div  class="tab-pane active" id='tab2'><img  class='img-responsive' src={data}/><p>Can't generate enrichment heatmap. Possible reasons:</p><p>1) the input dataset hasn't been significantly enriched in any co-expression clusters; </p><p>2) the selected reference dataset is not include information of co-expression cluster.</p></div>'''.format(data =dataArray[1]))
            elif dataArray[1] =='NA' and dataArray[2]=='NA':
                contentArray.append('''<div  class="tab-pane active" id='tab2'><p>Can't generate Manhattan plot. Possible reasons:</p> <p>1) the input dataset is not include P value; </p><p>2) the input dataset is not distributed in any co-expression clusters; </p> <p>3) the selected reference dataset is not include information of co-expression cluster.</p><br/><p>Can't generate enrichment heatmap. Possible reasons:</p><p>1) the input dataset hasn't been significantly enriched in any co-expression clusters; </p><p>2) the selected reference dataset is not include information of co-expression cluster.</p></div>''')
            else:
                 contentArray.append('''<div  class="tab-pane active" id='tab2'><img  class='img-responsive' src={data1}/><img  class='img-responsive' src={data2}/></div>'''.format(data1=dataArray[1],data2=dataArray[2]))
        else:
            hid = '#' + 'tab2-' + str(3*i)
            tabN = 'tab2-'+ str(3*i)
            itemsArray.append('''<li><a href={hid} aria-controls={data} role="tab" data-toggle="tab">{data}</a></li>'''.format(hid=hid,data=dataArray[3*i]))
            if dataArray[3*i+1] =='NA' and dataArray[3*i+2]!='NA':
                contentArray.append('''<div  class="tab-pane" id={tabN}><p>Can't generate Manhattan plot. Possible reasons:</p> <p>1) the input dataset is not include P value; </p><p>2) the input dataset is not distributed in any co-expression clusters; </p><p>3) the selected reference dataset is not include information of co-expression cluster.</p><img  class='img-responsive' src={data}/></div>'''.format(tabN=tabN,data=dataArray[3*i+2]))
            elif dataArray[3*i+1] !='NA' and dataArray[3*i+2] =='NA':
                contentArray.append('''<div  class="tab-pane" id={tabN}><img  class='img-responsive' src={data}/><p>Can't generate enrichment heatmap. Possible reasons:</p> <p>1) the input dataset hasn't been significantly enriched in any co-expression clusters; </p><p>2) the selected reference dataset is not include information of co-expression cluster.</p></div>'''.format(tabN=tabN,data=dataArray[3*i+1]))
            elif dataArray[3*i+1] =='NA' and dataArray[3*i+2] =='NA':
                contentArray.append('''<div  class="tab-pane" id={tabN}><p>Can't generate Manhattan plot. Possible reasons:</p> <p>1) the input dataset is not include P value; </p><p>2) the input dataset is not distributed in any co-expression clusters; </p> <p>3) the selected reference dataset is not include information of co-expression cluster.</p><br/><p>Can't generate enrichment heatmap. Possible reasons:</p><p>1) the input dataset hasn't been significantly enriched in any co-expression clusters; </p><p>2) the selected reference dataset is not include information of co-expression cluster.</p></div>'''.format(tabN=tabN))
            else:
                contentArray.append('''<div  class="tab-pane" id={tabN}><img  class='img-responsive' src={data1}/><img  class='img-responsive' src={data2}/></div>'''.format(tabN=tabN,data1=dataArray[3*i+1],data2=dataArray[3*i+2]))

    return itemsArray,contentArray


def Tab3Func(dataArray,items):

    itemsArray = []
    contentArray = []
    for i in xrange(len(dataArray)):
        if i==0:
            itemsArray.append(
                            '''<button type="button"  class="btn btn-default" data-toggle="collapse"
                            data-target="#collapse0">
                                {data}&nbsp;&nbsp;<span  class="caret"></span>
                            </button>'''.format(data=dataArray[0])
                        )

            item = items[dataArray[0]]

            itemsArray.append('''<div id="collapse0"  class="collapse in">''')
            for j in xrange(len(item)/2):
                if j == 0 :
                    itemsArray.append("""<li  class="active"><a  class="aa" href="#tab3" aria-controls={itemcontent} role="tab" role="tab" data-toggle="tab">{itemcontent}</a></li>""".format(itemcontent=item[0]))
                    contentArray.append('''<div  class="tab-pane active" id="tab3"><img  class="img-responsive" src={itemcontent}/></div>'''.format(itemcontent=item[1]))
                else:
                    hid = '#tab3-' + str(i) + "-" + str(j)
                    tabN = 'tab3-'+ str(i) + "-" + str(j)
                    itemsArray.append("""<li><a  class="aa" href={hid} aria-controls={itemcontent} role="tab" role="tab" data-toggle="tab">{itemcontent}</a></li>""".format(hid=hid,itemcontent=item[2*j]))
                    contentArray.append('''<div  class="tab-pane" id={tabN}><img  class="img-responsive" src={itemcontent}/></div>'''.format(tabN=tabN,itemcontent=item[2*j+1]))

            itemsArray.append('</div>')
        else:
            hrefid = "#collapse" + str(i)
            itemsArray.append(
                '''<button type="button"  class="btn btn-default" data-toggle="collapse"
                data-target={hrefid}>
                        {data}&nbsp;&nbsp;<span  class="caret"></span>
                </button>'''.format(hrefid=hrefid,data=dataArray[i])
            )

            item = items[dataArray[i]]
            hrefid = "collapse" + str(i)
            itemsArray.append('''<div id={hrefid}  class="collapse">'''.format(hrefid=hrefid))
            for j in xrange(len(item)/2):
                hid = '#tab3-' + str(i) + "-" + str(j)
                tabN = 'tab3-' + str(i) + "-" + str(j)
                itemsArray.append('''<li><a  class="aa" href={hid} aria-controls={itemcontent} role="tab" role="tab" data-toggle="tab">{itemcontent}</a></li>'''.format(hid=hid,itemcontent=item[2*j]))
                contentArray.append('''<div  class="tab-pane" id={tabN}><img  class="img-responsive" src={itemcontent}/></div>'''.format(tabN=tabN,itemcontent=item[2*j+1]))

            itemsArray.append('</div>')

    return itemsArray,contentArray



def tab4Option(dataArray):
    content4Array = []
    for i in xrange(len(dataArray)/2):
        content4Array.append('''<option value={data}>{data}</option>'''.format(data=dataArray[2*i]))
    return content4Array


def parseResult(resultDict):
    context = dict()
    context['jobName'] = resultDict['jobName']
    context['jobID'] = resultDict['jobID']

    inputArray = list()
    inputArray.append('*******')
    context['inputArray'] = inputArray

    refDataArray = resultDict['refData'].split(',')
    context['refDataArray'] = list()
    for item in refDataArray:
        context['refDataArray'].append('''<p>{item}</p>'''.format(item=item))

    if resultDict.get('venn'):
        venn='''<p><img  class='img-responsive' src={venn}/></p>'''.format(
                venn=resultDict.get('venn'))
        context['venn'] = venn

    context['SNPPvalueMethod'] = resultDict['SNPPvalueMethod']
    context['SNPCutOff'] = resultDict['SNPCutOff']
    context['jobStarted'] = resultDict['jobStarted']
    context['jobFinished'] = resultDict['jobFinished']
    context['Download'] = resultDict['Download']
    tab1ItemsArray, tab1ContentArray = TabFunc(resultDict['tab1'], 'tab1')
    context['tab1ItemsArray'] = tab1ItemsArray
    context['tab1ContentArray'] = tab1ContentArray

    if len(resultDict['tab2'])==0:
        tab2Pcontent='''<div class='col-sm-offset-3 col-sm-9 column'>
                            <p>Can't generate Manhattan plot. Possible reasons:</p>
                            <p>1) the input dataset is not include P value; </p>
                            <p>2) the input dataset is not distributed in any co-expression clusters; </p>
                            <p>3) the selected reference dataset is not include information of co-expression cluster.</p>
                            <br/>
                            <p>Can't generate enrichment heatmap. Possible reasons:</p>
                            <p>1) the input dataset hasn't been significantly enriched in any co-expression clusters; </p>
                            <p>2) the selected reference dataset is not include information of co-expression cluster.</p>
                        </div>
                     '''
        context['tab2Pcontent'] = tab2Pcontent
    else:
        tab2ItemsArray, tab2ContentArray = Tab2Func(resultDict['tab2'])
        context['tab2ItemsArray'] = tab2ItemsArray
        context['tab2ContentArray'] = tab2ContentArray

    if len(resultDict['tab3'])==0:
        tab3Pcontent='''<p>The input dataset hasn't been significantly enriched in any co-expression clusters or the selected reference dataset is not include information of co-expression cluster.</p>'''
        context['tab3Pcontent'] = tab3Pcontent
    else:
        tab3ItemsArray, tab3ContentArray = Tab3Func(resultDict['tab3'], resultDict)
        context['tab3ItemsArray'] = tab3ItemsArray
        context['tab3ContentArray'] = tab3ContentArray

    if len(resultDict['tab4'])==0:
        tab4Pcontent='''<p>The input dataset hasn't been significantly enriched in any co-expression clusters or the selected reference dataset is not include information of co-expression cluster.</p>'''
        context['tab4Pcontent'] = tab4Pcontent
    else:
        content4Array = tab4Option(resultDict['tab4'])
        context['content4Array'] = content4Array
        context['tab4Dict'] = resultDict['tab4']
    return context



if __name__ == '__main__':
    app.debug = True
    app.run(port=8081, host="127.0.0.1")