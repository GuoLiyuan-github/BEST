from flask import Flask, request, make_response, redirect, url_for, jsonify,render_template
import json
import datetime
import os
import uuid
import sys
sys.path.append("/home/BEST/application")
import db_v2
import db_search
import subprocess




app = Flask(__name__, static_url_path='')

UPLOAD_FOLDER = './test/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def index():
    return app.send_static_file('index.html')



@app.route('/run',methods=['POST'])
def run():
    #print request.json
 
    projParm = request.form.to_dict()
    print(projParm)
    print(type(projParm))
    jobname=projParm['JobName'] 
    print(jobname)
    #file=request.files['file']
    #print(type(file))
    #print(file)
    #file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))

    #projParm = request.get_json()
    #print type(projParm['JobName'])
    #print projParm
    return json.dumps('123')


@app.route('/job/<jobid>', methods=['POST', 'GET'])
def job(jobid):
    if request.method == 'POST':
        resultDict = {
            "status":'done',
            'jobName':'test1',
            'jobID':'123',
            'DType':'Plink',
            'logP':True,
            'refData':'data1,data2,data3',
            'LD':True,
            'dataResourse':'eur',
            'SNPPvalueMethod':'fdr_by',
            'SNPCutOff':'0.05',
            'GenePvalueMethod':'fdr_by',
            'GeneCutOff':'0.01',
            'SNPwindow':'10',
            'jobStarted':'9:08:05',
            'jobFinished':'9:10:06',
	    'venn':'./data/92dfa6d8-0267-11e9-a506-20040ff01498/venn.png',
            'tab1': [
                'data1',
                './data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png',
                'data3 expression',
                './data/915eadc0-032c-11e9-92da/clusterdata3/Results/expression.png',
                "clusterdata1_celltype",
                "./data/915eadc0-032c-11e9-92da/clusterdata1/Results/celltype.png",
                "clusterdata3_celltype",
                "./data/915eadc0-032c-11e9-92da/clusterdata3/Results/celltype.png"
            ],
            'tab2': ['clusterdata1', 'clusterdata3'],
            'clusterdata1': [
                'N_paleturquoise',
                './data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_paleturquoise.txt.exp.png',
                'N_lightcyan1',
                './data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_lightcyan1.txt.exp.png'
            ],
            'clusterdata3': [
                'N_blue',
                './data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_blue.txt.exp.png',
                'N_darkgrey',
                './data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_darkgrey.txt.exp.png'
            ],
	    'tab3': [
                'cytoscape',
                './images/homepage/website-testfig1.png'
	    ],
	    'tab4':[
		'manhatten',
		'./data/92dfa6d8-0267-11e9-a506-20040ff01498/manhatten.png'
	    ],
        }
        return json.dumps(resultDict)


#@app.route('/job/<jobid>',methods=['POST','GET'])
#def job(jobid):
#    if request.method == 'POST':
#        resultDict = {"status":"running"}
#        return  json.dumps(resultDict)
#



if __name__ == '__main__':
    app.debug = True    
    app.run(port=8080,host="0.0.0.0")
