from flask import Flask, request, make_response, redirect, url_for, jsonify,render_template
from flask_mail import Mail, Message
from threading import Thread
import json
import datetime
import uuid
import sys
import os
sys.path.append("/home/BEST/application")
import db_v2
import db_search
import subprocess


app = Flask(__name__, static_url_path='', template_folder='static')
UPLOAD_FOLDER = '/home/BEST/test/'
app.config['UPLOAD_FOLDER'] = '/home/BEST/test'
app.config.update(
    MAIL_SERVER='mail.cstnet.cn',
    MAIL_PORT=994,
    MAIL_USE_TLS = False,
    MAIL_USE_SSL = True,
    MAIL_USERNAME='bioinfo@psych.ac.cn',
    MAIL_PASSWORD='bioinfo123456',
    MAIL_DEGUB=True
)

mail = Mail(app)


def send_async_email(app,msg):
    with app.app_context():
        mail.send(msg)

#@app.route('/mail')
#def send_mail():
#    msg = Message('Job Submitted - BEST server',
#                  sender=('BEST server', 'bioinfo@psych.ac.cn'),
#                  recipients=['AAA@outlook.com'])
#    msg.html='<h3>You BEST job (job ID: '+jobID+') has been submitted. The results can be retrieved from the following URL http://best.psych.ac.cn/'+jobID
#
#    thread=Thread(target=send_async_email, args=[app,msg])
#    thread.start()
#
#    return 'Successful'


@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/run',methods=['POST'])
def run():
    projParm = request.form.to_dict()
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    print(projParm)
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
#    projParm = request.get_json()
#    print(projParm)
    jobID=str(uuid.uuid1())[:23]
    jobname=projParm['JobName']
    inputData=projParm['inputData']
    inType=projParm['DType']
    logP=str(projParm['logP'])
    #expData=",".join(projParm['refData'])
    expData=projParm['refData']
    print(type(expData))
    print(expData)
    LD='false'
    LD_data=projParm['dataResourse']
    genePcut=projParm['SNPCutOff']
    gPvalCor=projParm['SNPPvalueMethod']
    clusterPcut=projParm['GeneCutOff']
    cPvalCor=projParm['GenePvalueMethod']
    SNPwin=projParm['SNPwindow']
    email=projParm['email']
#    filedir=projParm['fileData']
#    f=open(filedir, "r")
#    print(type(filedir))
    status="running"
    error="not finished"
    db_v2.insert_sql(jobname, jobID, inType, logP, LD_data, SNPwin, expData, genePcut, gPvalCor, clusterPcut, cPvalCor, email, status, error)
    Num_cluster=str(len(projParm['refData']))
    os.mkdir("/home/BEST/data/"+jobID)
    jobpath="/home/BEST/data/"+jobID+"/"
    
    if inputData!="":
        f=open("/home/BEST/data/"+jobID+"/inputdata", "w")
        f.write(inputData)
        f.close()
        print(genePcut)
        print(gPvalCor)
        cmd="sh /home/BEST/application/run_pipeline.sh "+jobpath+"inputdata "+jobpath+" "+Num_cluster+" "+expData+" "+jobID+" "+inType+" "+logP+" "+LD_data+" "+SNPwin+" "+genePcut+" "+gPvalCor+" "+clusterPcut+" "+cPvalCor+" &"
        subprocess.call(cmd, shell=True) 
    elif inputData=="":
        if projParm.get('demo',0)=="demo":
            cmd="cp /home/BEST/demo_data/demo.txt /home/BEST/data/"+jobID+"/inputdata" 
            subprocess.call(cmd, shell=True)
            cmd="sh /home/BEST/application/run_pipeline.sh "+jobpath+"inputdata "+jobpath+" "+Num_cluster+" "+expData+" "+jobID+" "+inType+" "+logP+" "+LD_data+" "+SNPwin+" "+genePcut+" "+gPvalCor+" "+clusterPcut+" "+cPvalCor+" &"
            subprocess.call(cmd, shell=True)
    
        else:
       #print(projParm['file'])
            file=request.files['file']
            print(type(file))
            print(file)
            print(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))
     
            cmd="mv /home/BEST/test/"+file.filename+" /home/BEST/data/"+jobID+"/inputdata"
            subprocess.call(cmd, shell=True)
            cmd="sh /home/BEST/application/run_pipeline.sh "+jobpath+"inputdata "+jobpath+" "+Num_cluster+" "+expData+" "+jobID+" "+inType+" "+logP+" "+LD_data+" "+SNPwin+" "+genePcut+" "+gPvalCor+" "+clusterPcut+" "+cPvalCor+" &"
            subprocess.call(cmd, shell=True) 
        #print("222222222222222222222222222222222")
    
########################################################
    if email!="":
        msg = Message('Job Submitted - BEST server',
                      sender=('BEST server', 'bioinfo@psych.ac.cn'),
                      recipients=[email])
        msg.html='<h3>You BEST job (job ID: '+jobID+'; job name: '+jobname+') has been submitted. The results can be retrieved from the following URL http://best.psych.ac.cn/'+jobID
    
        thread=Thread(target=send_async_email, args=[app,msg])
        thread.start()
########################################################
    return json.dumps(jobID)


@app.route('/<jobid>', methods=['POST', 'GET'])
def job(jobid):
    print("----------------------------------------------------------------")
    print(jobid)
    print("----------------------------------------------------------------")
    #status, time, finished=db_v2.search_sql('e18d2d3e-04d6-11e9-a581')
    #print(status,time,finished)
    #print(type(time))
#    para=request.get_json()
#    jobid=para['jobID']
    status, jobname, jobid, dataType, logP, refData, LDdata, gPcut, gPcor, cPcut, cPcor, SNPwin, begin, ending=db_v2.search_sql_all(jobid)
    print( status, jobname, jobid, dataType, logP, refData, LDdata, gPcut, gPcor, cPcut, cPcor, SNPwin, begin, ending)
    #status, jobname, jobid, dataType, logP, refData, LDdata, gPcut, gPcor, cPcut, cPcor, SNPwin, begin, ending=db_v2.search_sql_all('e18d2d3e-04d6-11e9-a581')
    if status=='finished':
        status='done'
    else:
        print("----------------------------------------------------------------")
        print(status)
        print("----------------------------------------------------------------")
    
    resultDict = {
        #'jobStarted':"09:18 2018 08 08",
        "status":status,
        'jobName':jobname,
        'jobID':jobid,
        'DType':dataType,
        'logP':str(logP),
        'refData':refData,
        'dataResourse':LDdata,
        'SNPPvalueMethod':gPcor,
        'SNPCutOff':gPcut,
        'GenePvalueMethod':cPcor,
        'GeneCutOff':cPcut,
        'SNPwindow':SNPwin,
        'jobStarted':str(begin),
        'jobFinished':str(ending),}

    Results_path='/home/BEST/data/'+jobid+"/"
    if os.path.isfile(Results_path+"all_result.tar"):
        Downloadfile='.'+Results_path[10:]+"all_result.tar"
    else:
        #Downloadfile='.'+Results_path[10:]+"error"
        Downloadfile=[]
        print("no result file")

    if os.path.isfile(Results_path+"enrich.png"):
        venn_plotfile='.'+Results_path[10:]+"enrich.png"
    else:
        venn_plotfile=[]
        print("no venn file")

    resultDict['Download']=Downloadfile
    resultDict['venn']=venn_plotfile

    tab1_list=[]
    tab4_list=[]
    for root,dirs,files in os.walk(Results_path):
        for name in dirs:
            if name[:11] == "clusterdata":
                if name=="clusterdata1":
                    title="RNA-seq Data from Brainspan"
                elif name=="clusterdata2":
                    title="Microaray data from Allen Brain altas"
                elif name=="clusterdata3":
                    title="Microaray data from Brainspan"
                elif name=="clusterdata4":
                    title="RNA-seq data from He Z et al, 2014"
                elif name=="clusterdata5":
                    title="RNA-seq data from Xu C et al, 2018"
                elif name=="clusterdata6":
                    title="RNA-seq data from He Z et al, 2017"
                elif name=="clusterdata7":
                    title="RNA-seq data from GTEx"
                elif name=="clusterdata8":
                    title="RNA-seq data from Lister R et al, 2013"
                expression_data=root+name+"/Results/expression.png"
#                celltype_data=root+name+"/Results/celltype.png"
                man_data=root+name+"/Results/manhattan.png"
                if os.path.isfile(expression_data):
                    tab1_list.append(title+" expression level")
                    tab1_list.append('.'+expression_data[10:])
#                if os.path.isfile(celltype_data):
#                    tab1_list.append(title+" celltype")
#                    tab1_list.append('.'+celltype_data[10:]) 
                if os.path.isfile(man_data):
                    tab4_list.append(title+" cluster-based manhattan Plot")
                    tab4_list.append('.'+man_data[10:])
    resultDict['tab1']=tab1_list
    resultDict['tab4']=tab4_list


    tab2_list=[]
    for root,dirs,files in os.walk(Results_path):
        for name in dirs:
            if name[:11] == "clusterdata":
                if name=="clusterdata1":
                    title="RNA-seq Data from Brainspan"
                elif name=="clusterdata2":
                    title="Microaray data from Allen Brain altas"
                elif name=="clusterdata3":
                    title="Microaray data from Brainspan"
                elif name=="clusterdata4":
                    title="RNA-seq data from He Z et al, 2014"
                elif name=="clusterdata5":
                    title="RNA-seq data from Xu C et al, 2018"
                elif name=="clusterdata6":
                    title="RNA-seq data from He Z et al, 2017"
                elif name=="clusterdata7":
                    title="RNA-seq data from GTEx"
                elif name=="clusterdata8":
                    title="RNA-seq data from Lister R et al, 2013"

                tab2_list.append(title)
                cluster_list=[]
                celltype_data=root+name+"/Results/celltype.png"
                if os.path.isfile(celltype_data):
                    cluster_list.append("celltype enrichment")
                    cluster_list.append('.'+celltype_data[10:])
                for root_1,dirs_1,files_1 in os.walk(root+name+"/Results/"):
                     for filename in files_1:
                         if filename[:2]=='N_' and filename[-3:]=='png':
                             cluster_list.append(filename[:-12])
                             cluster_list.append('.'+root_1[10:]+filename)
                resultDict[title]=cluster_list
    resultDict['tab2']=tab2_list
    
    tab3_list=[]
    for root,dirs,files in os.walk(Results_path):
        for name in dirs:
            if name[:11] == "clusterdata":
                if name=="clusterdata1":
                    title="RNA-seq Data from Brainspan"
                elif name=="clusterdata2":
                    title="Microaray data from Allen Brain altas"
                elif name=="clusterdata3":
                    title="Microaray data from Brainspan"
                elif name=="clusterdata4":
                    title="RNA-seq data from He Z et al, 2014"
                elif name=="clusterdata5":
                    title="RNA-seq data from Xu C et al, 2018"
                elif name=="clusterdata6":
                    title="RNA-seq data from He Z et al, 2017"
                elif name=="clusterdata7":
                    title="RNA-seq data from GTEx"
                elif name=="clusterdata8":
                    title="RNA-seq data from Lister R et al, 2013"

                tab3_list.append(title)
                cluster_list=[]
                for root_1,dirs_1,files_1 in os.walk(root+name+"/Results/"):
                     for filename in files_1:
                         if filename[:2]=='N_' and filename[-4:]=='plot':
                             cluster_list.append(filename[:-5])
                             cluster_list.append(root_1+filename)
#                resultDict[name]=cluster_list
                resultDict['cytoscape']=cluster_list
    resultDict['tab3']=tab3_list

    if request.method == 'POST':
        return json.dumps(resultDict)

    if request.method == 'GET':
        if resultDict.get('status') != 'done':
            return render_template('remain.html')
        else:
            context = parseResult(resultDict)
            return render_template('job.html',**context)

def TabFunc(dataArray, tabNum):
    itemsArray = list()
    contentArray = list()
    print(len(dataArray))
    print(type(len(dataArray)))
    for iIndex in range(int(len(dataArray) / 2)):
        if iIndex == 0:
            hid = '#' + tabNum
            itemsArray.append(
                '''<li class="active"><a href={hid} aria-controls={data} role="tab" role="tab" data-toggle="tab">{data}</a></li>'''.
                format(hid=hid, data=dataArray[0]))
            contentArray.append(
                '''<div class="tab-pane active" id={tabNum}><img class='img-responsive' src={data}/></div>'''.
                format(tabNum=tabNum, data=dataArray[1]))
        else:
            hid = '#' + tabNum + str(2 * iIndex)
            itemsArray.append(
                '''<li><a href={hid} aria-controls={data} role="tab" data-toggle="tab">{data}</a></li>'''.
                format(hid=hid, data=dataArray[2 * iIndex]))
            contentArray.append(
                '''<div class="tab-pane" id={tabnum}><img class='img-responsive' src={data}/></div>'''.
                format(
                    tabnum=tabNum + str(2 * iIndex),
                    data=dataArray[2 * iIndex + 1]))
    return itemsArray, contentArray

def Tab2Func(dataArray, items):
    itemsArray = list()
    contentArray = list()
    for iIndex in range(len(dataArray)):
        if iIndex == 0:
            itemsArray.append('''<p>{data}</p>'''.format(data=dataArray[0]))
            item = items[dataArray[0]]
            for kIndex in range(int(len(item) / 2)):
                if kIndex == 0:
                    itemsArray.append(
                        '''<li class="active"><a href="#tab2" aria-controls={item0} role="tab" role="tab" data-toggle="tab">{item0}</a></li>'''.
                        format(item0=item[0]))
                    contentArray.append(
                        '''<div class="tab-pane active" id='tab2'><img class='img-responsive' src={item1}/></div>'''.
                        format(item1=item[1]))
                else:
                    hid = '#tab2-' + str(iIndex) + '-' + str(kIndex)
                    itemsArray.append(
                        '''<li><a href={hid} aria-controls={item2K} role="tab" role="tab" data-toggle="tab">{item2K}</a></li>'''.
                        format(hid=hid, item2K=item[2 * kIndex]))
                    contentArray.append(
                        '''<div class="tab-pane" id={tabK}><img class='img-responsive' src={item2K1}/></div>'''.
                        format(
                            tabK='tab2-' + str(iIndex) + '-' + str(kIndex),
                            item2K1=item[2 * kIndex + 1]))
        else:
            item = items[dataArray[iIndex]]
            itemsArray.append(
                '''<p>{data}</p>'''.format(data=dataArray[iIndex]))
            for kIndex in range(int(len(item) / 2)):
                hid = '#tab2-' + str(iIndex) + '-' + str(kIndex)
                itemsArray.append(
                    '''<li><a href={hid} aria-controls={item2K} role="tab" role="tab" data-toggle="tab">{item2K}</a></li>'''.
                    format(hid=hid, item2K=item[2 * kIndex]))
                contentArray.append(
                    '''<div class="tab-pane" id={tabN}><img class='img-responsive' src={item2K1}/></div>'''.
                    format(
                        tabN='tab2-' + str(iIndex) + '-' + str(kIndex),
                        item2K1=item[2 * kIndex + 1]))
    return itemsArray, contentArray

def parseResult(resultDict):
    context = dict()
    context['jobName'] = resultDict['jobName']
    context['jobID'] = resultDict['jobID']

    if resultDict['DType'] =='SNPandP':
        context['Dtype'] = 'SNP list (with p-value)'
    elif resultDict['DType'] =='GENEandP':
        context['Dtype'] = 'Gene list (with p-value)'
    elif resultDict['DType'] =='SNPList':
        context['Dtype'] = 'SNP list (without p-value)'
    elif resultDict['DType'] =='GeneList':
        context['Dtype'] = 'Gene list (without p-value)'

            
    if resultDict['logP'] =='true':
        context['logP'] = 'Y'
    elif resultDict['logP'] =='false':
        context['logP'] = 'N'

    if resultDict['SNPwindow'] ==0:
        context['snpWindow'] = "within gene"
    elif resultDict['SNPwindow'] ==10:
        context['snpWindow'] = '10 kb upstream and downstream of gene'
    elif resultDict['SNPwindow'] ==50:
        context['snpWindow'] = '50 kb upstream and downstream of gene'


    refDatadic = {'data1':'1.RNA-seq Data from Brainspan (with co-expression clusters)',
                  'data2':'2.Microaray data from Allen Brain altas (with co-expression clusters)',
                  'data3':'3.Microaray data from Brainspan (with co-expression clusters)',
                  'data4':'4.RNA-seq data from He Z et al, 2014',
                  'data5':'5.RNA-seq data from Xu C et al, 2018 (with co-expression clusters)',
                  'data6':'6.RNA-seq data from He Z et al, 2017',
                  'data7':'7.RNA-seq data from GTEx (with co-expression clusters)',
                  'data8':'8.RNA-seq data from Lister R et al, 2013'}

    refDataArray = resultDict['refData'].split(',')
    context['refDataArray'] = list()
    for item in refDataArray:
        context['refDataArray'].append('''<p>{item}</p>'''.format(item=refDatadic[item]))


    if resultDict.get('venn'):
        venn='''<p><img className='img-responsive' src={venn}/></p>'''.format(
                venn=resultDict.get('venn'))
        context['venn'] = venn

    context['SNPPvalueMethod'] = resultDict['SNPPvalueMethod']
    context['SNPCutOff'] = resultDict['SNPCutOff']
    context['jobStarted'] = resultDict['jobStarted']
    context['jobFinished'] = resultDict['jobFinished']
    context['Download'] = resultDict['Download']
    tab1ItemsArray, tab1ContentArray = TabFunc(resultDict['tab1'], 'tab1')
    context['tab1ItemsArray'] = tab1ItemsArray
    context['tab1ContentArray'] = tab1ContentArray
    tab2ItemsArray, tab2ContentArray = Tab2Func(resultDict['tab2'], resultDict)
    context['tab2ItemsArray'] = tab2ItemsArray
    context['tab2ContentArray'] = tab2ContentArray
    tab3ItemsArray, tab3ContentArray = TabFunc(resultDict['tab3'], 'tab3')
    context['tab3ItemsArray'] = tab3ItemsArray
    context['tab3ContentArray'] = tab3ContentArray
    tab4ItemsArray, tab4ContentArray = TabFunc(resultDict['tab4'], 'tab4')
    context['tab4ItemsArray'] = tab4ItemsArray
    context['tab4ContentArray'] = tab4ContentArray
    return context

















#            'Download':'./data/92dfa6d8-0267-11e9-a506-20040ff01498/clusterdata1/Result.tar',
#            'venn':'./data/92dfa6d8-0267-11e9-a506-20040ff01498/venn.png',
#            'tab1': [
#                'data1',
#                './data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png',
#                'data3 expression',
#                './data/915eadc0-032c-11e9-92da/clusterdata3/Results/expression.png',
#                "clusterdata1_celltype",
#                "./data/915eadc0-032c-11e9-92da/clusterdata1/Results/celltype.png",
#                "clusterdata3_celltype",
#                "./data/915eadc0-032c-11e9-92da/clusterdata3/Results/celltype.png"
#            ],
#            'tab2': ['clusterdata1', 'clusterdata3'],
#            'clusterdata1': [
#                'N_paleturquoise',
#                './data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_paleturquoise.txt.exp.png',
#                'N_lightcyan1',
#                './data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_lightcyan1.txt.exp.png'
#            ],
#            'clusterdata3': [
#                'N_blue',
#                './data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_blue.txt.exp.png',
#                'N_darkgrey',
#                './data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_darkgrey.txt.exp.png'
#            ],
#            'tab3': [
#                'cytoscape',
#                './images/homepage/website-testfig1.png'
#            ],
#            'tab4':[
#                'manhatten',
#                './data/92dfa6d8-0267-11e9-a506-20040ff01498/manhatten.png'
#            ],
#        }
#        print(resultDict)
#        return json.dumps(resultDict)
#    elif request.method == 'GET':
#        return json.dumps('123')







#@app.route('/job/<jobid>',methods=['GET'])
#@app.route('/job/<jobid>',methods=['POST','GET'])
#def job(jobid):
#    status,begin,ending=db_v2.search_sql(jobid) 
##    if status == 'finished':
##        return "job done.........!"
#    if request.method == 'POST':
#        if status == 'running':
#            resultDict = {"status":"running"}
#            return json.dumps(resultDict)
#        elif status == 'failed':
#            resultDict = {"status":"failed"}
#            return json.dumps(resultDict)
#        else:
#            resultDict = {"status":"finished",
#		          'tab1':['data1 expression','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png','data3 expression','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png', "clusterdata1_celltype", "/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/celltype.png", "clusterdata3_celltype", "/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/celltype.png"],
#			  'tab2':['clusterdata1','clusterdata3'],
#			  'clusterdata1':['N_paleturquoise','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_paleturquoise.txt.exp.png','N_lightcyan1','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_lightcyan1.txt.exp.png'],
#                          'clusterdata3':['N_blue','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_blue.txt.exp.png','N_darkgrey','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_darkgrey.txt.exp.png'],
#                           }
#            return json.dumps(resultDict)
#    elif request.method == 'GET':
#        if status == 'running':
#            resultDict = {"status":"running"}
#            return json.dumps(resultDict)
#        elif status == 'failed':
#            resultDict = {"status":"failed"}
#            return json.dumps(resultDict)
#        else:
#            resultDict = {"status":"finished",
#                          'tab1':['data1 expression','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png','data3 expression','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/expression.png', "clusterdata1_celltype", "/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/celltype.png", "clusterdata3_celltype", "/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/celltype.png"],
#                          'tab2':['clusterdata1','clusterdata3'],
#                          'clusterdata1':['N_paleturquoise','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_paleturquoise.txt.exp.png','N_lightcyan1','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata1/Results/N_lightcyan1.txt.exp.png'],
#                          'clusterdata3':['N_blue','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_blue.txt.exp.png','N_darkgrey','/home/BEST/data/915eadc0-032c-11e9-92da/clusterdata3/Results/N_darkgrey.txt.exp.png'],
#                           }
#            return json.dumps(resultDict)





#        if status == 'running':
#            return "waiting...........!"
#        render_template('job.html', results_dict)

#    if request.method == 'POST':
#    #   status=db_v2.search_sql(jobID)
#     #   print(status)
#        dirslist="11111"
#        status="111"
#        print(status)
#        return  json.dumps(status)
#    elif request.method == 'GET':
#        return 'hahah'


if __name__ == '__main__':
    app.debug = True
    app.run(port=8080,host="0.0.0.0")
