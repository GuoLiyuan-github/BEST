from flask import Flask
from flask_mail import Mail, Message
from threading import Thread

app = Flask(__name__)
app.config.update(
    MAIL_SERVER='mail.cstnet.cn',
    MAIL_PORT=994,
    MAIL_USE_TLS = False,
    MAIL_USE_SSL = True,
    MAIL_USERNAME='bioinfo@psych.ac.cn',
    MAIL_PASSWORD='bioinfo123456',
    MAIL_DEGUB=True
)

mail = Mail(app)

def send_async_email(app,msg):
    with app.app_context():
        mail.send(msg)

jobID='123456'
recipient='bioinfo@psych.ac.cn'
@app.route('/mail')
def send_mail():
    msg = Message('Hello',
                  sender=('BEST server', 'bioinfo@psych.ac.cn'),
                  recipients=[recipient])
   # msg.html = 'Hello World'+jobid
    msg.html='<h3>You BEST job (job ID: '+jobID+') has completed. The results can be retrieved from the following URL http://best.psych.ac.cn/'+jobID
    thread=Thread(target=send_async_email, args=[app,msg])
    thread.start()    

    return 'Successful'


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
