# -*- coding: utf-8 -*-
### LOAD MODULES
from collections import Counter
import pymysql
import time
import os

def couting(input, output):
    f=open(input, "r")
    geneID=[]
    next(f)
    for line in f.readlines():
        temp=line.split()
        geneID.append(temp[0])
        geneID.append(temp[1])
    f.close()

    a=Counter(geneID)
    print(a)

    f=open(output, "w")
    for item, values in Counter(geneID).items():
        print(item)
        print(values)
        f.write(str(item)+" "+str(values)+"\n")
    f.close()
    return

# for counting db
def create_db(inputfile, table_name):
    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db", local_infile=1)
    cursor=database.cursor()

    sql_comm1="create table "+table_name+" like temp_gene_linkcount;"
    sql_comm2="load data local infile '"+inputfile+"' into table "+table_name+" FIELDS terminated by ' 'lines terminated by'\\n';"
    try:
        cursor.execute(sql_comm1)
        database.commit()
        cursor.execute(sql_comm2)
        database.commit()
    except pymysql.Error as e:
        print(e)
        database.rollback()
    cursor.close()
    database.close()
    return

# for networking db
def create_tables(inputfile, table_name):
    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db", local_infile=1)
    cursor=database.cursor()
    
#    table_name="dataset1_E_cluster2"
    sql_comm1="create table "+table_name+" like dataset7_E_cluster24_1;"
    sql_comm2="load data local infile '/home/best-2/demo_data/E_cluster10.txt' into table "+table_name+" FIELDS terminated by '"+"\t"+"'lines terminated by'\n'(`fromNode`,`toNode`,`weight`,`direct`,`trash_1`,`trash_2`);"
#    sql_comm3="load data local infile '/home/best-2/demo_data/E_cluster10.txt' into table "+table_name+" FIELDS terminated by '\\t'lines terminated by'\\r\\n' IGNORE 1 LINES (`fromNode`,`toNode`,`weight`,`direct`,`trash_1`,`trash_2`);"
    sql_comm3="load data local infile '"+inputfile+"' into table "+table_name+" FIELDS terminated by '\\t'lines terminated by'\\r\\n' IGNORE 1 LINES (`fromNode`,`toNode`,`weight`,`direct`,`trash_1`,`trash_2`);"
    print(sql_comm3)
    try:
        cursor.execute(sql_comm1)
        database.commit()
        cursor.execute(sql_comm3)
        database.commit()
    except pymysql.Error as e:
        database.rollback()
        print("insert error!") 
        print(e)
    
    cursor.close()
    database.close()
    return

def delete_tables(table_name):
    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db", local_infile=1)
    cursor=database.cursor()
    sql_comm="drop table if exists "+table_name+";"
    try:
        cursor.execute(sql_comm)
        database.commit()
    except pymysql.Error as e:
        database.rollback()
        print(e)
    cursor.close()
    database.close()
    return

def search_enrich_gene_single(inputfile, dataset, cluster):
    genelist_file=open(inputfile, "r")
    genelist=[]
    for line in genelist_file.readlines():
        temp=line.split()
        genelist.append(temp[0])
    genelist_file.close()

    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db")
    cursor = database.cursor()
    
    for i in range(len(genelist)):
        for j in range(len(genelist)):
            sql_comm="select * from dataset1_e_cluster63 where (fromNode='"+genelist[i]+"' or fromNode='"+genelist[j]+"') and (toNode='"+genelist[i]+"' or toNode='"+genelist[j]+"');"
#            sql_comm="select * from dataset1_e_cluster63 where (fromNode='RTEL1' or fromNode='DIO3OS') and (toNode='RTEL1' or toNode='DIO3OS');"
#            print(sql_comm)
            try:
                cursor.execute(sql_comm)
                database.commit()
                data=cursor.fetchall()
                print(data)
#                print(str(data[0])+" "+str(data[1])+" "+str(data[2]))
            except:
                database.rollback()
       
    cursor.close()
    database.close()
    return

def search_enrich_intersection(inputfile, table, outputfile):

    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db", local_infile=1)
    cursor = database.cursor()
    sql_comm1="load data local infile '"+inputfile+"' into table temp_table FIELDS terminated by ' ';"
    sql_comm2="select * from "+table+" as a where a.fromNode in (select gene from temp_table) and a.toNode in (select gene from temp_table);"
    sql_comm3="truncate table temp_table;"
    print(sql_comm1)
    try:
        cursor.execute(sql_comm1)
        database.commit()
    except:
        database.rollback()
        print("error")
    output=open(outputfile, "w")
    for i in range(len(dataset)):
        print(dataset[i])
        try:
    #        data = cursor.fetchall()
            cursor.execute(sql_comm2)
            database.commit()
            data=cursor.fetchall()
    #        print(data)
            for row in data:
                output.write(str(row[0])+" "+str(row[1])+" "+str(row[2])+"\n")
            cursor.execute(sql_comm3)
            database.commit()
        except pymysql.Error as e:
            database.rollback()
            print(e)
            print("error")
    cursor.close()
    database.close()
    return

def search_enrich_intersection_update(inputfile, temp_table, table, outputfile):
    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db", local_infile=1)
    cursor = database.cursor()
    sql_comm0="create table "+temp_table+" like temp_table_v1;"
    sql_comm1="load data local infile '"+inputfile+"' into table "+temp_table+" FIELDS terminated by ' ';"
    sql_comm2="select * from "+table+" as a where a.fromNode in (select gene from "+temp_table+") and a.toNode in (select gene from "+temp_table+");"
#    sql_comm3="truncate table temp_table;"
    sql_comm3="drop table "+temp_table+";"
    try:
        cursor.execute(sql_comm0)
        database.commit()
        cursor.execute(sql_comm1)
        database.commit()
    except pymysql.Error as e:
        database.rollback()
        print(e)
    output=open(outputfile, "w")
    try:
#        data = cursor.fetchall()
        cursor.execute(sql_comm2)
        database.commit()
        data=cursor.fetchall()
#        print(data)
        for row in data:
            output.write(str(row[0])+" "+str(row[1])+" "+str(row[2])+"\n")
        cursor.execute(sql_comm3)
        database.commit()
    except pymysql.Error as e:
        database.rollback()
        print(e)
    cursor.close()
    database.close()
    output.close()
    return

def search_top_20(inputfile, temp_table1, temp_table2, count_table, network_table, outputfile):
    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db", local_infile=1)
    cursor = database.cursor()
#    sql_comm1="create table "+temp_table1+" like temp_table;"
    sql_comm1="create table "+temp_table1+" like temp_table_geneset;"
    sql_comm2="load data local infile '"+inputfile+"' into table "+temp_table1+" FIELDS terminated by ' ';"
#    sql_comm3="create table "+temp_table2+" select * from "+count_table+" as a where (a.gene in (select gene from "+temp_table1+")) order by count desc limit 20;"
    sql_comm3_1="select count from "+count_table+" as a where (a.gene in (select gene from "+temp_table1+")) order by count desc limit 20;"
    sql_comm4="select * from "+network_table+" as a where a.fromNode in (select gene from "+temp_table2+") and a.toNode in (select gene from "+temp_table2+");"
    sql_comm5="drop table "+temp_table1+";"
    sql_comm6="drop table "+temp_table2+";"
    print(sql_comm1)
    print(sql_comm2)
    print(sql_comm3_1)
    print(sql_comm4)
    print(sql_comm5)
    print(sql_comm6)
   # sql_comm=sql_comm1+sql_comm2+sql_comm3+sql_comm4
   # print(sql_comm)
    output=open(outputfile, "w")
    try:
        cursor.execute(sql_comm1)
        database.commit()
        cursor.execute(sql_comm2)
        database.commit()
        cursor.execute(sql_comm3_1)
        cutoff=str((cursor.fetchall())[-1][0])
        sql_comm3_2="create table "+temp_table2+" select * from "+count_table+" as a where (a.gene in (select gene from "+temp_table1+")) and a.count >="+cutoff+" order by count desc;"
        print(sql_comm3_2)
        cursor.execute(sql_comm3_2)
#        database.commit()
        print(sql_comm4)
        cursor.execute(sql_comm4)
        data=cursor.fetchall()

        for row in data:
            output.write(str(row[0]) + " " + str(row[1]) + " " + str(row[2]) + "\n")
        cursor.execute(sql_comm5)
        database.commit()
        cursor.execute(sql_comm6)
        database.commit()
    except pymysql.Error as e:
        database.rollback()
        print(e)

    cursor.close()
    database.close()
    output.close()
    return

if __name__=="__main__":
    start=time.time()
    all_data=['dataset1','dataset2','dataset3','dataset5','dataset7']
    for i in all_data:
        print(i) 
        if i=='dataset1':
            for m in range(1,64):    # 1 to 9
               input_data='/home/best-2/reference_data/cluster_reference/Study_one_cluster_result/edges_gene/E_cluster'+str(m)+'.txt' 
               table=i+'_E_cluster'+str(m)
               print(input_data)
               print(table)
               create_tables(input_data, table)
        elif i=='dataset2':
            for m in range(1,35):
               input_data='/home/best-2/reference_data/cluster_reference/Study_two_cluster_result/edges_gene/E_cluster'+str(m)+'.txt' 
               table=i+'_E_cluster'+str(m)
               print(input_data)
               print(table)
               create_tables(input_data, table)
        elif i=='dataset3':
            for m in range(1,30):
               input_data='/home/best-2/reference_data/cluster_reference/Study_three_cluster_result/edges_gene/E_cluster'+str(m)+'.txt' 
               table=i+'_E_cluster'+str(m)
               print(input_data)
               print(table)
               create_tables(input_data, table)
        elif i=='dataset5':
            for m in range(1,36):
               input_data='/home/best-2/reference_data/cluster_reference/Study_five_cluster_result/edges_gene/E_cluster'+str(m)+'.txt' 
               table=i+'_E_cluster'+str(m)
               print(input_data)
               print(table)
               create_tables(input_data, table)
        elif i=='dataset7':
            for m in range(1,26):
               input_data='/home/best-2/reference_data/cluster_reference/Study_seven_cluster_result/edges_gene/E_cluster'+str(m)+'.txt' 
               table=i+'_E_cluster'+str(m)
               print(input_data)
               print(table)
               create_tables(input_data, table)

        dataset_list = ["Study_one_cluster_result", "Study_two_cluster_result", "Study_three_cluster_result",
                        "Study_five_cluster_result", "Study_seven_cluster_result"]
        for datasetID in dataset_list:
            print(datasetID)
            if datasetID == "Study_one_cluster_result":
                table_1 = "dataset1"
            elif datasetID == "Study_two_cluster_result":
                table_1 = "dataset2"
            elif datasetID == "Study_three_cluster_result":
                table_1 = "dataset3"
            elif datasetID == "Study_five_cluster_result":
                table_1 = "dataset5"
            elif datasetID == "Study_seven_cluster_result":
                table_1 = "dataset7"
            directory = "/home/best-2/reference_data/cluster_reference/" + datasetID + "/edges_gene/"
            location = os.listdir(directory)
            print(location)
            for edgesfiles in location:
                if os.path.splitext(edgesfiles)[1] == ".txt":
                    input_cluster = os.path.join(directory, edgesfiles)
                    output_cluster = os.path.join(directory, edgesfiles + ".count")
                    #                couting(input_cluster, output_cluster)
                    table_name = table_1 + "_" + edgesfiles[:-4] + "_" + "count"
                    create_db(output_cluster, table_name)
    #                delete_db(table_name)

    end=time.time()
    print('Running time: %.0f second' % (end - start))
