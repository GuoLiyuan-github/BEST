# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2018/11/19

library(pheatmap)
library(data.table)
library(Cairo)

args<-commandArgs()
#test<-read.table("celltype", header=F, sep=" ")
test<-read.table(args[6], header=F, sep=" ")
colnames(test)<-c("astrocytes","endothelial","microglia","neurons","oligodendrocytes")
row_name<-read.table(args[9], header=F)
#rownames(test)<-levels(unlist(row_name[1]))
rownames(test)<-unlist(row_name[1])
#rownames(test)<-lapply(row_name[1], as.character)
#test1<-t(test)
#pheatmap(test1, colorRampPalette(c("royalblue1","white"))(50), strCol=45)
#pheatmap(test, colorRampPalette(c("royalblue1","white","white","white","white"))(100))
#pheatmap(-log10(test+0.01), colorRampPalette(c("white","royalblue1"))(100), filename=args[7])
pheatmap(-log10(test+0.01), cluster_rows=F, cluster_cols=F, colorRampPalette(c("white","cornflowerblue", "olivedrab3","steelblue2"))(100), filename=args[7])

CairoPNG(file=args[8], width=1024, height=768)
pheatmap(-log10(test+0.01), cluster_rows=F, cluster_cols=F, colorRampPalette(c("white", "khaki", "darkgoldenrod1", "chocolate", "firebrick3"))(200), fontsize=20)
dev.off()

pheatmap(-log10(test+0.01), cluster_rows=T, cluster_cols=T, colorRampPalette(c("white","cornflowerblue", "olivedrab3","steelblue2"))(100), filename=args[10])

CairoPNG(file=args[11], width=1024, height=768)
pheatmap(-log10(test+0.01), cluster_rows=T, cluster_cols=T, colorRampPalette(c("white", "khaki", "darkgoldenrod1", "chocolate", "firebrick3"))(200), fontsize=20)
dev.off()