# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2018/12/11
library(Cairo)
library(VennDiagram)

args<-commandArgs()

x<-read.table(args[6])
y<-read.table(args[7])
z<-read.table(args[8])
xx<-read.table(args[9])
yy<-read.table(args[10])

a<-levels(unlist(x))
b<-levels(unlist(y))
c<-levels(unlist(z))
d<-levels(unlist(xx))
e<-levels(unlist(yy))

m<-args[11]
n<-args[12]
o<-args[13]
p<-args[14]
q<-args[15]

data<-list(a,b,c,d,e)
names(data)<-c(m,n,o,p,q)

venn.plot<-venn.diagram(data,
            cat.pos =c(-45, 0, 180, 180, 135) ,NULL,fill=c("yellow","blue", "red","green", "cyan"),alpha=0.3, cex=2 )

pdf(args[17])
grid.draw(venn.plot)

CairoPNG(file=args[16])
grid.draw(venn.plot)
dev.off()
