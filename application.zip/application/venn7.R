# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2019/1/25
library(Cairo)
library(VennDiagram)

args<-commandArgs()

x<-read.table(args[6])
y<-read.table(args[7])
z<-read.table(args[8])
xx<-read.table(args[9])
yy<-read.table(args[10])
zz<-read.table(args[11])
xxx<-read.table(args[12])

a<-levels(unlist(x))
b<-levels(unlist(y))
c<-levels(unlist(z))
d<-levels(unlist(xx))
e<-levels(unlist(yy))
f<-levels(unlist(zz))
g<-levels(unlist(xxx))

m<-args[13]
n<-args[14]
o<-args[15]
p<-args[16]
q<-args[17]
r<-args[18]
s<-args[19]

data<-list(a,b,c,d,e,f,g)
names(data)<-c(m,n,o,p,q,r,s)

CairoPNG(file=args[20])
venn.plot<-venn.diagram(data,NULL,fill=c("yellow","blue", "red","green", "cyan", "purple", "orange"),alpha=0.3, cex=2 )
grid.draw(venn.plot)
dev.off()
