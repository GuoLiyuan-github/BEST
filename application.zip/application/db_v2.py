#
import pymysql
import uuid

print(str(uuid.uuid1()))

def insert_sql(jobname, jobid, inType, logP, LD, SNPwin, expData, genePcut, gPvalCor, clusterPcut, cPvalCor, email, status, error):
    database=pymysql.connect(host="localhost", port=3306,user="best",passwd="best@mysql", db="best_db")
    cursor=database.cursor()
    sql="insert into job_log_update (timeDate, modified_time, jobName, jobID, jobDir, inputType ,logP, SNPwindow, LD_ref, expressionDataSet, genePcut, gAdjustedMethod, cEnrichPcut, cAdjustedMethod, emailAddr, status, errorMessages) values (now(), now(), '"+jobname+"', '"+jobid+"', '/home/BEST/data/"+jobid+"', '"+inType+"', '"+logP+"', '"+SNPwin+"','"+LD+"', '"+expData+"', '"+genePcut+"', '"+gPvalCor+"', '"+clusterPcut+"', '"+cPvalCor+"', '"+email+"', '"+status+"', '"+error+"');"
    print(sql)
    try:
        cursor.execute(sql)
        database.commit()
    except:
        database.rollback()
        print("database insert error!")
    cursor.close()
    database.close()
    return

def update_sql(jobid: object, status: object, error: object) -> object:
    """

    :rtype: object
    """
    database=pymysql.connect(host="localhost", port=3306,user="best",passwd="best@mysql", db="best_db")
    cursor=database.cursor()
    sql="UPDATE job_log_update SET modified_time=now(), Status='"+status+"', errorMessages='"+error+"' WHERE jobID='"+jobid+"'"
    try:
        cursor.execute(sql)
        database.commit()
    except:
        database.rollback()
        print("database update error!")
    cursor.close()
    database.close()
    return

def search_sql(jobid):
    database=pymysql.connect(host="localhost", port=3306,user="best",passwd="best@mysql", db="best_db")
    cursor=database.cursor()
    sql="select status, timeDate, modified_time from job_log_update where jobId='"+jobid+"';"
    try:
        cursor.execute(sql)
        database.commit()
        data = cursor.fetchall()
        value=list(data[0])
        status=value[0]
        start_time=value[1]
        finish_time=value[2]
    except:
        database.rollback()
        print("database searching error!")
    cursor.close()
#    return
    database.close()
    return status, start_time, finish_time

def search_sql_all(jobid):
    database=pymysql.connect(host="localhost", port=3306,user="best",passwd="best@mysql", db="best_db")
    cursor=database.cursor()
    sql="select status, jobName, jobID, inputType, logP, SNPwindow, LD_ref, expressionDataSet, genePcut, gAdjustedMethod, cEnrichPcut, cAdjustedMethod, timeDate, modified_time from job_log_update where jobId='"+jobid+"';"
    try:
        cursor.execute(sql)
        database.commit()
        data = cursor.fetchall()
        value=list(data[0])
        status=value[0]
        jobname=value[1]
        jobid=value[2]
        dataType=value[3]
        logP=value[4]
        SNPwin=value[5]
        LDdata=value[6]
        refData=value[7]
        gPcut=value[8]
        gPcor=value[9]
        cPcut=value[10]
        cPcor=value[11]
        start_time=value[12]
        finish_time=value[13]
    except:
        database.rollback()
#        print("database searching error!")
        status='error'
        jobname=""
        jobid=""
        dataType=""
        logP=""
        SNPwin=""
        LDdata=""
        refData=""
        gPcut=""
        gPcor=""
        cPcut=""
        cPcor=""
        start_time=""
        finish_time=""
    cursor.close()
    #    return
    database.close()
    return status, jobname, jobid, dataType, logP, refData, LDdata, gPcut, gPcor, cPcut, cPcor, SNPwin, start_time, finish_time

if __name__=="__main__":
    database=pymysql.connect(host="localhost", port=3306,user="best",passwd="best@mysql", db="best_db")
    cursor=database.cursor()
#
    jobid=str(uuid.uuid1())
    jobname="test_DB"
    jobDir="/home/BEST"
    inType="SNPandP"
    logP="yes"
    LD="eur"
    expData="1"
    snpwin=str(10)
    genePcut=str(0.01)
    gPvalCor="fdr_bh"
    clusterPcut=str(0.01)
    cPvalCor="fdr_bh"
    email="test@dumb.com"
    status="running"
    error="Null"
    insert_sql(jobname, jobid, inType, logP, LD, snpwin, expData, genePcut, gPvalCor, clusterPcut, cPvalCor, email, status, error)
    update_sql(jobid, "finish", "gooood!")
    a,b,c=search_sql(jobid)
    print(a)
    print(b)
    print(c)

    status, jobname, jobid, dataType, logP, refData, LDdata, gPcut, gPcor, cPcut, cPcor, SNPwin, start_time, finish_time=search_sql_all(jobid)
    print(status, jobname, jobid, dataType, logP, refData, LDdata, gPcut, gPcor, cPcut, cPcor, SNPwin, start_time, finish_time)
    database.close()
