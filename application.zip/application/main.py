# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2018/12/12

import db
import pymysql
import uuid

jobid=str(uuid.uuid1())

#db.update_sql("8c8564a0-fe00-11e8-8d04-20040ff01498", "finished", "Gooooood!")


