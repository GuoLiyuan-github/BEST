import os
import cytoscape_demo

jobid = '4889d5f2-1eb1-11e9-a807'

tab3_list=[]


network_data1="/home/best-2/data/"+jobid+"/clusterdata1/Results/all.top20"
network_data2="/home/best-2/data/"+jobid+"/clusterdata2/Results/all.top20"
network_data3="/home/best-2/data/"+jobid+"/clusterdata3/Results/all.top20"
network_data5="/home/best-2/data/"+jobid+"/clusterdata5/Results/all.top20"
network_data7="/home/best-2/data/"+jobid+"/clusterdata7/Results/all.top20"
network_data9="/home/best-2/data/"+jobid+"/clusterdata9/Results/all.top20"
network_data10="/home/best-2/data/"+jobid+"/clusterdata10/Results/all.top20"
if os.path.isfile(network_data1):
    tab3_list.append("RNA-seq Data from Brainspan")
    tab3_list.append(cytoscape_demo.getJsonFile(network_data1))
if os.path.isfile(network_data2):
    tab3_list.append("Microaray data from Allen Brain altas")
    tab3_list.append(cytoscape_demo.getJsonFile(network_data2))
if os.path.isfile(network_data3):
    tab3_list.append("Microaray data from Brainspan")
    tab3_list.append(cytoscape_demo.getJsonFile(network_data3))
if os.path.isfile(network_data5):
    tab3_list.append("RNA-seq data from Xu C et al, 2018")
    tab3_list.append(cytoscape_demo.getJsonFile(network_data5))
if os.path.isfile(network_data7):
    tab3_list.append("RNA-seq data from GTEx")
    tab3_list.append(cytoscape_demo.getJsonFile(network_data7))
if os.path.isfile(network_data9):
    tab3_list.append("RNA-seq Data from Brainspan(25x9)")
    tab3_list.append(cytoscape_demo.getJsonFile(network_data9))
if os.path.isfile(network_data10):
    tab3_list.append("Microaray data from Allen Brain altas(51x2)")
    tab3_list.append(cytoscape_demo.getJsonFile(network_data10))

print (tab3_list[1])

