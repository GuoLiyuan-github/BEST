import sys
import os
sys.path.append("/home/best-2/application")
import db_test_clusterplot
import cytoscape_demo
import pymysql

#database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db")
#cursor=database.cursor()
#sql="select count from dataset5_E_cluster26_count as a where (a.gene in (select gene from c823ecae197411e98c32_data5)) order by count desc limit 50;"
#cursor.execute(sql)
#data=(cursor.fetchall())[-1][0]
#print(data)
#
#
#cursor.close()
#database.close()

#filename='N_cluster50.top20'
#db=cytoscape_demo.getJsonFile(filename)
#print(db)


#for i in 2,3,5,7:
#    for j in range(1,120):
#        table_name="dataset"+str(i)+"_e_cluster"+str(j)
#        table_name2=table_name+"_count"
#        db_test_clusterplot.delete_tables(table_name)
#        db_test_clusterplot.delete_tables(table_name2)
#    print(i)
#
#all_data=['dataset2','dataset3','dataset5','dataset7']
all_data=['dataset9','dataset10']

for i in all_data:
    if i=='dataset2':
        for m in range(1,33):
           input_data='/home/best-2/reference_data/cluster_reference/Study_two_cluster_result/edges_gene/E_cluster'+str(m)+'.txt'
           table=i+'_E_cluster'+str(m)
           print(input_data)
           print(table)
           db_test_clusterplot.create_tables(input_data, table)
    elif i=='dataset3':
        for m in range(1,103):
           input_data='/home/best-2/reference_data/cluster_reference/Study_three_cluster_result/edges_gene/E_cluster'+str(m)+'.txt'
           table=i+'_E_cluster'+str(m)
           print(input_data)
           print(table)
           db_test_clusterplot.create_tables(input_data, table)
    elif i=='dataset5':
        for m in range(1,49):
           input_data='/home/best-2/reference_data/cluster_reference/Study_five_cluster_result/edges_gene/E_cluster'+str(m)+'.txt'
           table=i+'_E_cluster'+str(m)
           print(input_data)
           print(table)
           db_test_clusterplot.create_tables(input_data, table)
    elif i=='dataset7':
        for m in range(1,112):
           input_data='/home/best-2/reference_data/cluster_reference/Study_seven_cluster_result/edges_gene/E_cluster'+str(m)+'.txt'
           table=i+'_E_cluster'+str(m)
           print(input_data)
           print(table)
           db_test_clusterplot.create_tables(input_data, table)
    elif i=='dataset9':
        for m in range(1,46):
           input_data='/home/best-2/reference_data/cluster_reference/Study_one_refine/edges_gene/E_cluster'+str(m)+'.txt'
           table=i+'_E_cluster'+str(m)
           print(input_data)
           print(table)
           db_test_clusterplot.create_tables(input_data, table)
    elif i=='dataset10':
        for m in range(1,36):
           input_data='/home/best-2/reference_data/cluster_reference/Study_two_refine/edges_gene/E_cluster'+str(m)+'.txt'
           table=i+'_E_cluster'+str(m)
           print(input_data)
           print(table)
           db_test_clusterplot.create_tables(input_data, table)
#dataset_list = ["Study_two_cluster_result", "Study_three_cluster_result",
#                "Study_five_cluster_result", "Study_seven_cluster_result"]
#for datasetID in dataset_list:
#    print(datasetID)
#    if datasetID == "Study_two_cluster_result":
#        table_1 = "dataset2"
#    elif datasetID == "Study_three_cluster_result":
#        table_1 = "dataset3"
#    elif datasetID == "Study_five_cluster_result":
#        table_1 = "dataset5"
#    elif datasetID == "Study_seven_cluster_result":
#        table_1 = "dataset7"
#    directory = "/home/best-2/reference_data/cluster_reference/" + datasetID + "/edges_gene/"
#    location = os.listdir(directory)
#    print(location)
#    for edgesfiles in location:
#        if os.path.splitext(edgesfiles)[1] == ".txt":
#            input_cluster = os.path.join(directory, edgesfiles)
#            output_cluster = os.path.join(directory, edgesfiles + ".count")
#            db_test_clusterplot.couting(input_cluster, output_cluster)
#            table_name = table_1 + "_" + edgesfiles[:-4] + "_" + "count"
#            db_test_clusterplot.create_db(output_cluster, table_name)
