# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2018/11/1
library(pheatmap)
library(data.table)
library(Cairo)     ### for saving fig avoiding X11
library(ggplot2)
args<-commandArgs()

#test<-read.table(args[6], header=F, sep='\t', row.names=1)
test<-read.table(args[6], header=F, sep='\t')
#names(test)=
#print(test)
#pheatmap(test, color = colorRampPalette(colors = c("blue", "cyan", "green", "yellow", "orange", "white"))(100))
#pheatmap(test, color = colorRampPalette(c("royalblue1","white"))(50), fontsize=9, fontsize_row=6)
bk = unique(c(seq(-5,5, length=100)))
#pheatmap(test)
#pheatmap(log2(test+1))
#pheatmap(log2(test+1), cluster_rows=F, cluster_cols=F)
#color=colorRampPalette(c("white","royalblue1"))(100),
#pheatmap(log2(test+1), breaks=bk, cluster_rows=F, cluster_cols=F, show_colnames=F, fontsize_row=1, filename="heatmap.pdf")

#CairoPNG(file="expression.png", width=1024, height=768)
#pheatmap(log2(test+1), breaks=bk, cluster_rows=F, cluster_cols=F, fontsize=1, fontsize_row=1)
colname<-c("Early fetal","Mid-fetal","Late fetal",	"Neonatal and infancy", "Early childhood", "Middle and late childhood", "Adolescence","Young adulthood", "Middle adulthood", "Late adulthood")
rowname<-c("Frontal cortex"
,"Parietal cortex"
,"Temporal cortex"
,"Occipital cortex"
,"Hippocampus"
,"Amygdala"
,"Striatum"
,"Insula"
,"Parahippocampal gyrus"
,"Cingulate cortex"
,"Substantia nigra"
,"Nucleus accumbens"
,"Thalamus"
,"Olfactory bulb"
,"Hypothalamus"
,"Cerebellum")
#pheatmap(log2(test+0.05), cluster_rows=F, cluster_cols=F, show_colnames=F, fontsize_col=5, fontsize_row=4, filename=args[7])
pheatmap(log2(test+0.05), cluster_rows=F, cluster_cols=F, show_colnames=T, labels_col=colname, labels_row=rowname, fontsize_col=10, fontsize_row=10, na_col="grey75", filename=args[7])
CairoPNG(file=args[8], width=1024, height=768)
pheatmap(log2(test+0.05), cluster_rows=F, cluster_cols=F, show_colnames=T, labels_col=colname, labels_row=rowname, fontsize_col=15, fontsize_row=15, na_col="grey75")
#dev.off()
