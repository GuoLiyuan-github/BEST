# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2019/1/25
library(Cairo)
library(VennDiagram)

args<-commandArgs()

x<-read.table(args[6])
y<-read.table(args[7])
z<-read.table(args[8])
xx<-read.table(args[9])
yy<-read.table(args[10])
zz<-read.table(args[11])

a<-levels(unlist(x))
b<-levels(unlist(y))
c<-levels(unlist(z))
d<-levels(unlist(xx))
e<-levels(unlist(yy))
f<-levels(unlist(zz))

m<-args[12]
n<-args[13]
o<-args[14]
p<-args[15]
q<-args[16]
r<-args[17]

data<-list(a,b,c,d,e,f)
names(data)<-c(m,n,o,p,q,r)

CairoPNG(file=args[16])
venn.plot<-venn.diagram(data,
            cat.pos =c(-45, 0, 180, 180, 135) ,NULL,fill=c("yellow","blue", "red","green", "cyan", "purple"),alpha=0.3, cex=2 )
grid.draw(venn.plot)
dev.off()
