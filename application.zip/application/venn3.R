# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2018/12/11
library(Cairo)
library(VennDiagram)

args<-commandArgs()

x<-read.table(args[6])
y<-read.table(args[7])
z<-read.table(args[8])

a<-levels(unlist(x))
b<-levels(unlist(y))
c<-levels(unlist(z))

m<-args[9]
n<-args[10]
o<-args[11]

data<-list(a,b,c)
names(data)<-c(m,n,o)

venn.plot<-venn.diagram(data, NULL,fill=c("yellow","blue", "red"),alpha=0.3, cex=2)
pdf(args[13])
grid.draw(venn.plot)

CairoPNG(file=args[12])
grid.draw(venn.plot)
dev.off()
