import pymysql

database=pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db", local_infile=1)
cursor=database.cursor()

try:
    cursor.execute("create table zzz like temp_table_geneset;")
    database.commit()
    cursor.execute("load data local infile '/home/best-2/data/67103ade-25cd-11e9-8678/clusterdata7/Results/Gene_set' into table zzz FIELDS terminated by ' ';")
#    cursor.execute("drop table zzz")
    database.commit()
    cursor.execute("select count from dataset7_E_cluster105_count as a where (a.gene in (select gene from zzz)) order by count desc limit 20;")
    cutoff=str((cursor.fetchall())[-1][0])
    database.commit()
    print(cutoff)
    cursor.execute("create table zzz2 select * from dataset7_E_cluster105_count as a where (a.gene in (select gene from zzz)) and a.count >="+cutoff+" order by count desc;")
    database.commit()
    print("good")
except pymysql.Error as e:
    print(e)
    database.rollback()


