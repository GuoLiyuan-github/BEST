import argparse
import os
import subprocess

parser=argparse.ArgumentParser()
parser.add_argument("-id", "--jobid", help="job ID")
args=parser.parse_args()

path="/home/best-2/data/"+args.jobid

num_dirs = 0
cluster_dir=[]
plot_file_list=[]
venn_cluster=['clusterdata1', 'clusterdata2','clusterdata3', 'clusterdata5','clusterdata7' ]
for root,dirs,files in os.walk(path):
#    dirs.sort(key = lambda x: int(x[12:]))
    for name in dirs:
        if name[:13] in venn_cluster:
            if os.path.exists(path+"/"+name+"/Results/enrich.cluster."+name[7:]):
                if os.path.getsize(path+"/"+name+"/Results/enrich.cluster."+name[7:]):
                    num_dirs += 1
                    plot_file_list.append(path+"/"+name+"/Results/enrich.cluster."+name[7:])
                    cluster_dir.append(name)

cluster_dir.sort(key = lambda x: int(x[11:]))
plot_file_list.sort(key = lambda x: int(x[-1:]))
#print(plot_file_list)
num_overlap=len(list(set(cluster_dir).intersection(set(venn_cluster))))
#print(path)
#venn_output=path+'/enrich.png'
venn_output_png=path+'/Overview_cluster_enriched_gene.png'
venn_output_pdf=path+'/Overview_cluster_enriched_gene.pdf'
#print(venn_output)
#if num_dirs ==1 or num_dirs ==0:
if num_overlap ==1 or num_overlap ==0:
    print('no venn plot generated!')

#elif num_dirs ==2:
elif num_overlap ==2:
    #cmd="Rscript /home/best-2/application/venn2.R "+plot_file_list[0]+" "+plot_file_list[1]+" "+cluster_dir[0]+" "+cluster_dir[1]+" "+venn_output
    cmd="Rscript /home/best-2/application/venn2.R " +" ".join(plot_file_list)+" "+" ".join(cluster_dir)+" "+venn_output_png+" "+venn_output_pdf
    subprocess.call(cmd, shell=True)
    print("2 sets venn plot finished!")

elif num_overlap ==3:
    #cmd="Rscript /home/best-2/application/venn3.R "+plot_file_list[0]+" "+plot_file_list[1]+" "+plot_file_list[2]+" "+cluster_dir[0]+" "+cluster_dir[1]+" "+cluster_dir[2]+" "+venn_output
    cmd="Rscript /home/best-2/application/venn3.R " +" ".join(plot_file_list)+" "+" ".join(cluster_dir)+" "+venn_output_png+" "+venn_output_pdf
    subprocess.call(cmd, shell=True)
    print("3 sets venn plot finished!")

elif num_overlap ==4:
    #cmd="Rscript /home/best-2/application/venn4.R "+plot_file_list[0]+" "+plot_file_list[1]+" "+plot_file_list[2]+" "+plot_file_list[3]+" "+cluster_dir[0]+" "+cluster_dir[1]+" "+cluster_dir[2]+" "+cluster_dir[3]+" "+venn_output
    cmd="Rscript /home/best-2/application/venn4.R " +" ".join(plot_file_list)+" "+" ".join(cluster_dir)+" "+venn_output_png+" "+venn_output_pdf
    subprocess.call(cmd, shell=True)
    print("4 sets venn plot finished!")

elif num_overlap ==5:
    #cmd="Rscript /home/best-2/application/venn5.R "+plot_file_list[0]+" "+plot_file_list[1]+" "+plot_file_list[2]+" "+plot_file_list[3]+" "+plot_file_list[4]+" "+cluster_dir[0]+" "+cluster_dir[1]+" "+cluster_dir[2]+" "+cluster_dir[3]+" "+cluster_dir[4]+" "+venn_output
    cmd="Rscript /home/best-2/application/venn5.R " +" ".join(plot_file_list)+" "+" ".join(cluster_dir)+" "+venn_output_png+" "+venn_output_pdf
    subprocess.call(cmd, shell=True)
    print("5 sets venn plot finished!")
