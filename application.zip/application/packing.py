# -*- coding: utf-8 -*-
import sys
import os
import subprocess
sys.path.append("/home/best-2/application")
import pipeline_v8

job_dir="/home/best-2/data/"+str(sys.argv[1])+"/"
os.chdir(job_dir)

sub_datasets=[]
for root, dirs, files in os.walk(job_dir):
    for name in dirs:
        if name[:11]=="clusterdata":
            sub_datasets.append(name)
sub_datasets.sort(key=lambda x: int(x[11:]))
print(sub_datasets)

for name in sub_datasets:
    pack_file="dataset"+name[11:]+".tar"
    Result_dir=job_dir+name+"/Results"
    pipeline_v8.test_tar(pack_file, Result_dir, [".png",".pdf",".txt"])
#    cmd="cp "+pack_file+" "+job_dir
#    subprocess.call(cmd, shell=True)

pack_file=job_dir+"Results.tar"
Result_dir=job_dir
print(Result_dir)
pipeline_v8.test_tar(pack_file, Result_dir, [".png",".pdf",".txt", ".tar"])
