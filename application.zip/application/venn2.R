# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2018/12/11
library(Cairo)
library(VennDiagram)

args<-commandArgs()

x<-read.table(args[6])
y<-read.table(args[7])

a<-levels(unlist(x))
b<-levels(unlist(y))

m<-args[8]
n<-args[9]

data<-list(a,b)
names(data)<-c(m,n)

venn.plot<-venn.diagram(data, NULL, fill=c("yellow","blue"),alpha=0.3, cex=2)
pdf(args[11])
grid.draw(venn.plot)

CairoPNG(file=args[10])
grid.draw(venn.plot)
dev.off()
#######



###########names(a)<-c(abc, bcd)
