# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2018/11/1
# original cell_heatmap.R
library(pheatmap)
library(data.table)
library(Cairo)     ### for saving fig avoiding X11
library(ggplot2)
args<-commandArgs()

#test<-read.table(args[6], header=F, sep='\t', row.names=1)
test<-read.table(args[6], header=F, sep='\t')
if(args[9]=="data1") {
    bk = unique(c(seq(-4,8, length=100)))
} else if (args[9]=="data2") {
    bk = unique(c(seq(0,3, length=100)))
} else if (args[9]=="data3") {
    bk = unique(c(seq(1.7,3.2, length=100)))
} else if (args[9]=="data4") {
    bk = unique(c(seq(-5,6, length=100)))
} else if (args[9]=="data5") {
    bk = unique(c(seq(-0.8,8.8, length=100)))
} else if (args[9]=="data6") {
    bk = unique(c(seq(-5,6, length=100)))
} else if (args[9]=="data7") {
    bk = unique(c(seq(-4.5,9.5, length=100)))
} else if (args[9]=="data8") {
    bk = unique(c(seq(-5,7, length=100)))
} else if (args[9]=="data9") {
    bk = unique(c(seq(-4,9, length=100)))
} else if (args[9]=="data10") {
    bk = unique(c(seq(0.8,3.1, length=100)))
}
colname<-c("Early fetal","Mid-fetal","Late fetal",	"Neonatal and infancy", "Early childhood", "Middle and late childhood", "Adolescence","Young adulthood", "Middle adulthood", "Late adulthood")
rowname<-c("Frontal cortex"
,"Parietal cortex"
,"Temporal cortex"
,"Occipital cortex"
,"Hippocampus"
,"Amygdala"
,"Striatum"
,"Insula"
,"Parahippocampal gyrus"
,"Cingulate cortex"
,"Substantia nigra"
,"Nucleus accumbens"
,"Thalamus"
,"Olfactory bulb"
,"Hypothalamus"
,"Cerebellum")
pheatmap(breaks=bk, log2(test+0.05), cluster_rows=F, cluster_cols=F, show_colnames=T, labels_col=colname, labels_row=rowname, fontsize_col=10, fontsize_row=10, na_col="grey75", filename=args[7])
CairoPNG(file=args[8], width=1024, height=768)
pheatmap(breaks=bk, log2(test+0.05), cluster_rows=F, cluster_cols=F, show_colnames=T, labels_col=colname, labels_row=rowname, fontsize_col=15, fontsize_row=15, na_col="grey75")
#dev.off()
