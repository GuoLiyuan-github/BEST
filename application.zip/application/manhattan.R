# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2018/10/31

### import library
library(qqman)
library(data.table)
library(Cairo)     ### for saving fig avoiding X11
#
args<-commandArgs()
#file<-list.files(pattern="cluster_gene_pval", full.names=TRUE)
#file<-list.files(pattern="/Bioinfo/MDDRD2/PMO/pumc/project/BESTproject/Pipeline_v2/Results/cluster_gene_pval")#, full.names=TRUE)
dd<-read.table(args[6], header=T, sep=",")
#str(dd)
#head(dd)
pdf(args[7], width=10)
manhattan(dd,chr="chrID", bp="position", snp="geneID", p="pvalue", main="Manhattan Plot", col=c("blue4", "orange3"), cex=0.6, suggestiveline=F, genomewideline=F, xlab="Cluster number")
#dev.off()

CairoPNG(file=args[8], width=1024, height=768)
manhattan(dd,chr="chrID", bp="position", snp="geneID", p="pvalue", main="Manhattan Plot", col=c("blue4", "orange3"), alpha=0.5, cex=0.6, suggestiveline=F, genomewideline=F, xlab="Cluster number")
dev.off()
