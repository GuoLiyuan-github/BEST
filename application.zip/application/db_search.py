import pymysql
import argparse
import time

def search_snploc(inputfile, path, window):
    snp_file=open(inputfile, "r")
    SNP = []
    table = []
    next(snp_file)
    for line in snp_file.readlines():
        temp = line.split()
        SNP.append(temp[0])
        table.append(temp[0][-1])
    snp_file.close()

    output = open(path+"snp.loc", "w")
    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db")
    cursor = database.cursor()
    if window=="0":
        for i in range(len(SNP)):
            sql = "select rsid, chr, pos from rs_inside_gene" + table[i] + " where rsid='" + SNP[i] + "';"
            try:
                cursor.execute(sql)
                database.commit()
                data = cursor.fetchall()
                for row in data:
                    output.write(str(row[0]) + " " + str(row[1][3:]) + " " + str(row[2]) + "\n")
            except:
                database.rollback()
                print("1111111111111111")

        cursor.close()
    elif window=="10":
        for i in range(len(SNP)):
            sql = "select rsid, chr, pos from rs_ud10k_gene" + table[i] + " where rsid='" + SNP[i] + "';"
            try:
                cursor.execute(sql)
                database.commit()
                data = cursor.fetchall()
                for row in data:
                    output.write(str(row[0]) + " " + str(row[1][3:]) + " " + str(row[2]) + "\n")
            except:
                database.rollback()
                print("1111111111111111")

        cursor.close()

    elif window=="50":
        for i in range(len(SNP)):
            sql = "select rsid, chr, pos from rs_ud50k_gene" + table[i] + " where rsid='" + SNP[i] + "';"
            try:
                cursor.execute(sql)
                database.commit()
                data = cursor.fetchall()
                for row in data:
                    output.write(str(row[0]) + " " + str(row[1][3:]) + " " + str(row[2]) + "\n")
            except:
                database.rollback()
                print("1111111111111111")

        cursor.close()
    output.close()
    database.close()
    return

if __name__=="__main__":
    start = time.time()
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input", help="input SNP file")
    parser.add_argument("-p", "--path", help="input SNP file path")
    parser.add_argument("-s", "--SNPwin", help="SNP upstream/downstream windows")
    args=parser.parse_args()

    search_snploc(args.input, args.path, args.SNPwin)
    print(time.asctime())
    end=time.time()
    print('Running time: %.0f second' % (end - start))
