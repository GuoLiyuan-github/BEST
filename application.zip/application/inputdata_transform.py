import argparse

def data_reform(input, output):
#    datalist=input.split("\n")
#    print(datalist)
    print(input)
    f=open(output, "w")
    f.write(input)
    f.close()
    return

if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input", help="input txt")
    parser.add_argument("-p", "--path", help="input SNP file path")
    args=parser.parse_args()

    data_reform(args.input, args.path)
