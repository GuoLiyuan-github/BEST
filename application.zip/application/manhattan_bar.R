# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2019/1/17
library(pheatmap)
library(data.table)
library(Cairo)

args<-commandArgs()
test<-read.table(args[6], header=F, sep=" ", row.names=1)
plot_data<-t(test[1])
rownames(plot_data)<-c(" ")
#bk=unique(c(seq(-2,2, length=100)))

#pheatmap(-log10(plot_data+0.01), cluster_rows=F, cluster_cols=F, colorRampPalette(c("white","cornflowerblue", "olivedrab3","steelblue2"))(100), filename=args[7], width=1024, height=340)
pheatmap(-log10(plot_data+0.01), cluster_rows=F, cluster_cols=F, colorRampPalette(c("white", "khaki", "darkgoldenrod1", "chocolate", "firebrick3"))(200), fontsize=10, filename=args[7], width=1024, height=125)

CairoPNG(file=args[8], width=1024, height=125)
pheatmap(-log10(plot_data+0.01), cluster_rows=F, cluster_cols=F, colorRampPalette(c("white", "khaki", "darkgoldenrod1", "chocolate", "firebrick3"))(200), fontsize=10)
