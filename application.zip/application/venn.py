import argparse
import os
import subprocess

parser=argparse.ArgumentParser()
parser.add_argument("-id", "--jobid", help="job ID")
args=parser.parse_args()

path="/home/BEST/data/"+args.jobid

num_dirs = 0
cluster_dir=[]
venn_cluster=['clusterdata1', 'clusterdata2','clusterdata3', 'clusterdata4','clusterdata5' ]
for root,dirs,files in os.walk(path):
    for name in dirs:
#        print(name[:11])
        if name[:11]=="clusterdata":
            num_dirs += 1
            cluster_dir.append(name)
            print(name)
print(cluster_dir)
print(num_dirs)

num_overlap=len(list(set(cluster_dir).intersection(set(venn_cluster))))

if num_dirs ==1:
    print('no venn plot generated!')
elif num_dirs ==2:
    cmd="Rscript venn2.R "


