# -*- coding: utf-8 -*-
"""
FILE NAME: pipeline_v5.py
DATE     : Dec. 2018
AUTHOR   : Mengchen P
NOTE     : update of pipeline_v4
           done: each jobs got its output dir
           done: each job got log-output instead of printing on screen
          new:  remove plink inputtype

Usage:
python3.6 pipeline_v5.py -input GeneandP -inType GENEandP -logP no -LDref eur -upSNPmapping 5 -expData 1 -gPcut 0.01 -gPvalCor bonferroni -cPcut 0.01 -cPvalCor fdr_bh -dir /home/best-2/data -jobID 001

input parameters:
-input: 
-inType: SNPandP GENEandP SNPList GeneList
-logP: yes no
-LDref: eur eas sas amr afr subpop
-upSNPmapping: 0 10 50
-expData: 1 2 3 4 5 6 7 8 9 10
-gPcut: 0.05    0.01    0.005   0.001
-gPvalCor: bonferroni sidak fdr_bh  fdr_by
-cPcut: 0.05    0.01    0.005   0.001   
-cPvalCor: bonferroni sidak fdr_bh  fdr_by
-dir:
-jobID

Output filelist:

"""

### LOAD MODULES
from statsmodels.sandbox.stats.multicomp import multipletests
from collections import Counter
import tarfile
import argparse
import sys
sys.path.append("/home/best-2/application")
import os
import subprocess
import time
import scipy.stats as stats
import numpy as np
import math
import db_test_clusterplot
##### running time
start = time.time()
starting_time = time.asctime()
print(str(starting_time))

### SET INPUT PARAMETERS
def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-input", "--inputFile", help="get input file")
    parser.add_argument("-inType", "--inputType", help="input file type")
    parser.add_argument("-logP", "--logPval", help="if P value is -log10 or not?")
    parser.add_argument("-LDref", "--LDref", help="define the LD reference")
    parser.add_argument("-upSNPmapping", "--UpDist", help="define SNPs mapping distance, upstream")
    parser.add_argument("-expData", "--expDataSet", help="define which set of expression data using for fisher")
    parser.add_argument("-gPcut", "--genePcut", help="Gene based P value cut off")
    parser.add_argument("-gPvalCor", "--gPvalCorrec", help="two methods")
    parser.add_argument("-cPcut", "--clusterPcut", help="Cluster enrichment P value cut off")
    parser.add_argument("-cPvalCor", "--cPvalCorrec", help="two methods")
    parser.add_argument("-jobID", "--jobID", help="get jobid and 'goto' job directory")
    args = parser.parse_args()
    return args

### SET cluster reference data
def get_cluster_path(expressionSet_num):
    expressionData_dir = "/home/best-2/reference_data/cluster_reference/"
    if expressionSet_num == "data1":
        expressionData_dir = expressionData_dir+"Study_one_cluster_result"
    elif expressionSet_num=="data2":
        expressionData_dir = expressionData_dir+"Study_two_cluster_result"
    elif expressionSet_num=="data3":
        expressionData_dir = expressionData_dir+"Study_three_cluster_result"
    elif expressionSet_num=="data4":
        expressionData_dir = expressionData_dir+"Study_four_cluster_result"
    elif expressionSet_num=="data5":
        expressionData_dir = expressionData_dir+"Study_five_cluster_result"
    elif expressionSet_num=="data6":
        expressionData_dir = expressionData_dir+"Study_six_cluster_result"
    elif expressionSet_num=="data7":
        expressionData_dir = expressionData_dir+"Study_seven_cluster_result"
    elif expressionSet_num=="data8":
        expressionData_dir = expressionData_dir+"Study_eight_cluster_result"
    elif expressionSet_num=="data9":
        expressionData_dir = expressionData_dir+"Study_one_refine"
    elif expressionSet_num=="data10":
        expressionData_dir = expressionData_dir+"Study_two_refine"
    return expressionData_dir

### check Pval if -log then pow back
def Pval_reformat(inputfile, LogP, output):
    """
    :param inputtype: Genelist; GENEandP; SNPandP; SNPList; Plink
    :return:
    """
    f1 = open(inputfile, "r")
    f2 = open(output, "w")
    if str.lower(LogP) == "true":
#        next(f1)
        for line in f1.readlines():
            temp = line.split()
            unlog_pval = math.pow(10, -float(temp[1]))
            f2.write(str(temp[0]) + " " + str(unlog_pval) + "\n")
    elif str.lower(LogP) == "false":
        cmd = "cp " + inputfile + " " + output
        subprocess.call(cmd, shell=True)
    return

### MAPPING DIFFERENT ID SYSTEM INTO GENE NAME
def GeneRename(input, orig):
    f = open("/home/best-2/reference_data/genename_ensembl.new", "r")
    orig1 = []  # ensemblID or entrezID
    replaced1 = []  # Gene name
    next(f)
    if orig == "entrezID":
        for line in f.readlines():
            temp = line.split()
            orig1.append(temp[1])
            replaced1.append(temp[0])
    elif orig == "ensemblID":
        for line in f.readlines():
            temp = line.split()
            orig1.append(temp[2])
            replaced1.append(temp[0])
    f.close()

    f = open(input, "r")
    next(f)
    output = open("replaced", "w")

    for line in f.readlines():
        line = line.strip('\n')  ### remove \n
        temp = line.split()
        oriID = temp[0]
        for j in range(len(orig1)):
            if oriID == orig1[j]:
                output.write(str(replaced1[j]) + "\t" + str(line) + "\n")
                # output.wirte(str(replaced1[j]) + "    " + str(line) + '\n')
                break
    output.close()
    f.close()
    return

### MULTITESTING Pval avoiding false positive
def multipletestingP(input, pcol, correctionMethod, cutoff, output):
    """
`bonferroni` : one-step correction
`sidak` : one-step correction
`holm-sidak` : step down method using Sidak adjustments
`holm` : step-down method using Bonferroni adjustments
`simes-hochberg` : step-up method  (independent)
`hommel` : closed method based on Simes tests (non-negative)
`fdr_bh` : Benjamini/Hochberg  (non-negative)
`fdr_by` : Benjamini/Yekutieli (negative)
`fdr_tsbh` : two stage fdr correction (non-negative)
`fdr_tsbky` : two stage fdr correction (non-negative)
    """
    ### start multitest, calculate q-value/Bonferroni corrected P value
    pval_input = open(input, "r")
    genes = []
    pvals = []
    for line in pval_input.readlines():
        temp = line.split()
        genes.append(temp[0])
        pvals.append(temp[pcol])  ### genes outputfile $10 is p_values
    pval_input.close()
    pvals = list(map(float, pvals))  # change data type from str to float for multiple test

    p_adjusted = multipletests(pvals=pvals, alpha=cutoff, method=correctionMethod, is_sorted=False, returnsorted=False)
    #    output = open("p_adjusted.out", "w")
    pval_output = open(output, "w")
    for index in range(len(p_adjusted[1])):
        pval_output.write(
            str(genes[index]) + "    " + str(p_adjusted[0][index]) + "    " + str(p_adjusted[1][index]) + "\n")
    pval_output.close()
    return

### EXPRESSION DATA EXTRACT
def expression(input, cluster, output, dataset):
    f1 = open(input, "r")
    f2 = open(cluster, "r")
    next(f2)

    interest_gene = []
    expression = []
    cluster_gene = []
    for line in f1.readlines():
        temp = line.split()
        interest_gene.append(temp[0])

    for line in f2.readlines():
        temp = line.split()
        expression.append(temp[1:])
        cluster_gene.append(temp[0])
    f1.close()
    f2.close()

    allexpression = []
    for i in range(len(interest_gene)):
        for j in range(len(cluster_gene)):
            if interest_gene[i] == cluster_gene[j]:
                allexpression.append(expression[j])
                # f.write(str(expression[j]))
            # print(expression[j]

    ### get average for all gene expression and generate expression matrix
    if dataset=="data1" or dataset=="data2" or dataset=="data3" or dataset=="data5" or dataset=="data7":
        avg_exp = np.mean(np.array(allexpression).astype(float), axis=0)
        avg_exp = np.reshape(avg_exp, (16, 10))
        f = open(output, "w")
        for i in range(len(avg_exp)):
            for j in range(0, 10):
                if j!=9:
                    f.write(str(avg_exp[i, j]) + "\t")
                elif j==9:
                    f.write(str(avg_exp[i, j]))
            f.write("\n")
        f.close()
    elif dataset=="data9":
        avg_exp = np.mean(np.array(allexpression).astype(float), axis=0)
        avg_exp = np.reshape(avg_exp, (25, 9))
        f = open(output, "w")
        for i in range(len(avg_exp)):
            for j in range(0, 9):
                if j!=8:
                    f.write(str(avg_exp[i, j]) + "\t")
                elif j==8:
                    f.write(str(avg_exp[i, j]))
            f.write("\n")
        f.close()
    elif dataset=="data10":
        avg_exp = np.mean(np.array(allexpression).astype(float), axis=0)
        avg_exp = np.reshape(avg_exp, (51, 2))
        f = open(output, "w")
        for i in range(len(avg_exp)):
            for j in range(0, 2):
                if j!=1:
                    f.write(str(avg_exp[i, j]) + "\t")
                elif j==1:
                    f.write(str(avg_exp[i, j]))
            f.write("\n")
        f.close()
    return

def network(genelistfile, nodeslistfile, connectionlistfile, output, output2):
    genelist = []
    nodeslist_orig = []
    connectionlist_1 = []
    connectionlist_2 = []
    connect = []
    f1 = open(genelistfile, "r")
    for line in f1.readlines():
        temp = line.split()
        genelist.append(temp[0])
    f1.close()

    f2 = open(nodeslistfile, "r")
    for line in f2.readlines():
        temp = line.split()
        nodeslist_orig.append(temp[0])
    f2.close()

    f3 = open(connectionlistfile, "r")
    for line in f3.readlines():
        temp = line.split()
        connectionlist_1.append(temp[0])
        connectionlist_2.append(temp[1])
        connect.append(temp)
    connect = np.array(connect)
    f3.close()
    # print(len(list(set(genelist).intersection(set(nodeslist_orig)))))
    #   print(list(set(genelist).intersection(set(nodeslist_orig))))

    f5 = open(output2, "w")
    for i in list(set(genelist).intersection(set(nodeslist_orig))):
        f5.write(i + "\n")
    f5.close()

    f4 = open(output, "w")
    for i in range(len(connectionlist_1)):
        if (connectionlist_1[i] in genelist) and (connectionlist_2[i] in genelist):
            f4.write(connect[i, 0] + "\t" + connect[i, 1] + "\t" + connect[i, 2] + "\t" + connect[i, 3] + "\t" + connect[i, 4] + "\t" + connect[i, 5] + "\n")
        # print(i)
    f4.close()
##    top20_hubgene=Counter(connectionlist_1+connectionlist_2).most_common(20)
##    print(top20_hubgene)

    f7 = open(output2+".top20", "w")
    top20_hubgene=[]
    for item, count in Counter(connectionlist_1+connectionlist_2).most_common(20):
        top20_hubgene.append(item)
#        f7.write(item+"\t"+str(count))
        f7.write(item+"\n")
    f7.close()

    f6 = open(output+".top20", "w")
#    print(top20_hubgene)
    for i in range(len(connectionlist_1)):
        if (connectionlist_1[i] in top20_hubgene) and (connectionlist_2[i] in top20_hubgene):
            f6.write(connect[i, 0] + "\t" + connect[i, 1] + "\t" + connect[i, 2] + "\t" + connect[i, 3] + "\t" + connect[i, 4] + "\t" + connect[i, 5] + "\n")
    f6.close()
    return


def network_1(genelistfile, nodeslistfile, output):
    genelist = []
    nodeslist_orig = []
    f1 = open(genelistfile, "r")
    for line in f1.readlines():
        temp = line.split()
        genelist.append(temp[0])
    f1.close()

    f2 = open(nodeslistfile, "r")
    for line in f2.readlines():
        temp = line.split()
        nodeslist_orig.append(temp[0])
    f2.close()

    f5 = open(output, "w")
    for i in list(set(genelist).intersection(set(nodeslist_orig))):
        f5.write(i + "\n")
    f5.close()

    return


def manhattan_prep(genefile, enrichfile, clusterfile, outputfile):
    ### generate fig manhattan plot
    #### data generation
    f1 = open(genefile, "r")  # f1 = open("candidate.list", "r")
    f2 = open(enrichfile, "r")  # f2 = open("clustergenelist", "r")
    f3 = open(clusterfile, "r")  # f3 = open("enrichment_module_adjusted.list", "r")
    output = open(outputfile, "w")  # output=open("cluster_gene_pval", "w")
    cluster_num = []
    clusterID = []
    enrichcluster_num = []
    gene_id2 = []
    gene_id1 = []
    pval = []
    for line in f1.readlines():
        temp = line.split()
        gene_id1.append(temp[0])
        #        pval.append(temp[9])       ### replaced file temp9/ candidate.list temp3
        pval.append(temp[3])
    #     pval.append(temp[1])
    for line in f2.readlines():
        temp = line.split()
        cluster_num.append(temp[2][9:])
        clusterID.append(temp[2])
        gene_id2.append(temp[0])
    for line in f3.readlines():
        temp = line.split()
        enrichcluster_num.append(temp[0])
    output.write("chrID,geneID,position,pvalue" + "\n")
    posi = 50
    clusterNo = 1
    for i in range(len(gene_id2)):
        for j in range(len(gene_id1)):
            if gene_id2[i] == gene_id1[j]:
#                if clusterID[i] in enrichcluster_num:
                    #                    print(clusterID[i])
                if str(cluster_num[i]) == str(clusterNo):
                    posi = posi + 1
                    # output.write(cluster_num[i]+","+gene_id2[i]+","+position[i]+","+pval[j]+"\n")
                    output.write(cluster_num[i] + "," + gene_id2[i] + "," + str(posi) + "," + pval[j] + "\n")
                else:
                    clusterNo = cluster_num[i]
                    posi = 10
                    output.write(cluster_num[i] + "," + gene_id2[i] + "," + str(posi) + "," + pval[j] + "\n")
    f1.close()
    f2.close()
    f3.close()
    output.close()

    return

def celltype_enrich():

    return

def test_tar(fname_out, dir_in):
    cur_path = os.getcwd()
    full_fname_out = os.path.join(cur_path, fname_out)
    full_path_in = os.path.join(cur_path, dir_in)
    os.chdir(full_path_in)
    tar = tarfile.open(full_fname_out, 'w:gz')
    for root, dir, files in os.walk(full_path_in):
        for file in files:
            if os.path.splitext(file)[1]==".pdf" or os.path.splitext(file)[1]==".png" or os.path.splitext(file)[1]==".list" or os.path.splitext(file)[1]==".plot" or os.path.splitext(file)[1]==".top20" or os.path.splitext(file)[1]==".expression":
                fullpath = file
                tar.add(fullpath, recursive=False)
    tar.close()
    os.chdir(cur_path)
    return


### main program
if __name__ == '__main__':
    # get input variable from arguments
    myparser = get_args()

    print('-----------------Starting Calculation-------------------')
    #if str(myparser.inputFile) == "None" or str(myparser.inputType) == "None" or str(myparser.logPval) == "None" or str(myparser.LDref) == "None" or str(myparser.UpDist) == "None" or str(myparser.expDataSet) == "None" or str(myparser.genePcut) == "None" or str(myparser.gPvalCorrec) == "None" or str(myparser.clusterPcut) == "None" or str(myparser.cPvalCorrec) == "None" or str(myparser.dirs)=="None" or str(myparser.jobID)=="None":
    if str(myparser.inputFile) == "None" or str(myparser.inputType) == "None" or str(myparser.logPval) == "None" or str(myparser.LDref) == "None" or str(myparser.UpDist) == "None" or str(myparser.expDataSet) == "None" or str(myparser.genePcut) == "None" or str(myparser.gPvalCorrec) == "None" or str(myparser.clusterPcut) == "None" or str(myparser.cPvalCorrec) == "None" or str(myparser.jobID)=="None":
        print(myparser)
        print("[ERROR]: Please check the input parameters!")
        print("[ERROR]: The calculation terminated!")
        print(str(time.asctime()))
        sys.exit()
    else:
        print("\n Parameters Good! \n")
        print('-------------------------------------------')

    ### get input parameters
    geneData = myparser.inputFile
    inType = myparser.inputType
    logP = myparser.logPval
    LDref = myparser.LDref
    LDrefloc = "/home/best-2/reference_data/LD_reference/g1000_" + LDref + "/g1000_" + LDref
    Upstream = myparser.UpDist
    Downstream = myparser.UpDist  # Downstream=myparser.DownDist #expData=myparser.expDataSet
    genePcut = float(myparser.genePcut)
    gPvalCor = myparser.gPvalCorrec
    clusterPcut = float(myparser.clusterPcut)
    cPvalCor = myparser.cPvalCorrec
    JobID=myparser.jobID
    Working_dir="/home/best-2/data/"+JobID
    expData = get_cluster_path(str(myparser.expDataSet))
    running_dir=Working_dir+"/cluster"+str(myparser.expDataSet)
    Result_dir=running_dir+"/Results/"
    # cluster data set directory initialization

    # initial job directory
    if not os.path.exists(Working_dir):
        os.mkdir(Working_dir)
    os.chdir(running_dir)
   
    # initial log file
    output_log=open('log', "w")
    
 #   print(str(os.getcwd()))
 #   output_log.write(str(myparser)+"\n")
 #   cmd = "cp /home/best-2/test/"+geneData+" ."
 #   subprocess.call(cmd, shell=True)

    ### create results directory
    if not os.path.exists("Results"):
        os.mkdir("Results")
    print("-----------------------------------Parameters initialization done!----------------------------------------")
    output_log.write("-----------------------------------Parameters initialization done!----------------------------------------"+"\n")
    ### different input file type
    if inType == "SNPandP":
        print("SNPandP")
        print(os.path.dirname(geneData))
        print(logP)
        Pval_reformat(geneData, logP, running_dir+"/SNPandP_format")
        cmd = "magma --annotate window=" + Upstream + "," + Downstream + " --snp-loc /home/best-2/data/"+JobID+"/snp.loc --gene-loc /home/best-2/depend_software/NCBI37.3/NCBI37.3.gene.loc --out "+running_dir+"/genelocation"
        subprocess.call(cmd, shell=True)
        cmd = "magma --bfile " + LDrefloc + " --gene-annot "+running_dir+"/genelocation.genes.annot --pval "+running_dir+"/SNPandP_format N=100000000 --out genePval"
        subprocess.call(cmd, shell=True)
        rename = GeneRename(running_dir+"/genePval.genes.out", "entrezID")  ###
        multitestP = multipletestingP("replaced", 9, gPvalCor, genePcut, "p_adjusted.out")
        cmd = "awk '{if($10<" + str(genePcut) + ") print $1, $2, $3, $10}' replaced > "+Result_dir+"candidate.list.orig"         ### change candidate.list to candidate.list.orig
        subprocess.call(cmd, shell=True)
        cmd="grep \'True\' p_adjusted.out| awk '{print $1, $2, \"NA\", $3}' > "+Result_dir+"candidate.list"                         ### change high conf to candidate list
        subprocess.call(cmd, shell=True)

    elif inType == "GENEandP":
        print("GENEandP")
        Pval_reformat(geneData, logP, running_dir + "/replaced")
        #cmd = "cp " + geneData + " replaced"
        #subprocess.call(cmd, shell=True)
        #multitestP = multipletestingP("replaced", 1, gPvalCor, genePcut, "p_adjusted.out")
        cmd = "awk '{if($10<" + str(genePcut) + ") print $1, 111, 111, $2}' replaced > "+Result_dir+"candidate.list"
        subprocess.call(cmd, shell=True)
        #cmd="grep \'True\' p_adjusted.out| awk '{print $1, $2, \"NA\", $3}' > "+Result_dir+"candidate.list"
        #subprocess.call(cmd, shell=True)

    elif inType == "SNPList":
        print("SNPList")
        cmd = "awk '{print $1, 1}' " + geneData + " > "+running_dir+"/SNPandP_format"
        subprocess.call(cmd, shell=True)
        cmd = "magma --annotate window=" + Upstream + "," + Downstream + " --snp-loc /home/best-2/data/"+JobID+"/snp.loc --gene-loc /home/best-2/depend_software/NCBI37.3/NCBI37.3.gene.loc --out "+running_dir+"/genelocation"
        subprocess.call(cmd, shell=True)
        cmd = "magma --bfile " + LDrefloc + " --gene-annot genelocation.genes.annot --pval SNPandP_format N=100000000 --out genePval"
        subprocess.call(cmd, shell=True)
        rename = GeneRename("genePval.genes.out", "entrezID")  ###
        cmd = "awk '{print $1}' replaced > "+Result_dir+"candidate.list"
        subprocess.call(cmd, shell=True)

    elif inType == "GeneList":
        print("GeneList")
        cmd = "cp " + geneData + " "+Result_dir+"candidate.list"
        subprocess.call(cmd, shell=True)
    print("-------------------------------------------------GWAS data done!----------------------------------------")
    output_log.write("-------------------------------------------------GWAS data done!----------------------------------------"+"\n")
    ### get expression heat map
    expression_data = expData + "/160_result_final.txt"
    expression(Result_dir+"candidate.list", expression_data, Result_dir+"expression.plotlist", str(myparser.expDataSet))
    cmd="Rscript /home/best-2/application/cell_heatmap.R "+Result_dir+"expression.plotlist "+Result_dir+"expression.pdf "+Result_dir+"expression.png"
    subprocess.call(cmd, shell=True)
    print("--------------------------------------  Expression for Gene Set done!----------------------------------------")
    output_log.write("--------------------------------------  Expression for Gene Set done!----------------------------------------"+"\n")
    if str(myparser.expDataSet)=="data4" or str(myparser.expDataSet)=="data6" or str(myparser.expDataSet)=="data8":
        pack_file = str(myparser.expDataSet) + "_result.tar"
        test_tar(pack_file, "Results")
        output_log.write("packing results...done!" + "\n")
        end = time.time()
        ending_time = time.asctime()
        print('Starting time: ' + str(starting_time) + '\t' + str(time.strftime('%Z', time.localtime())) + "\n")
        output_log.write(
            'Starting time: ' + str(starting_time) + '\t' + str(time.strftime('%Z', time.localtime())) + "\n")
        print('Finishing time: ' + str(ending_time) + '\t' + str(time.strftime('%Z', time.localtime())) + "\n")
        output_log.write(
            'Finishing time: ' + str(ending_time) + '\t' + str(time.strftime('%Z', time.localtime())) + "\n")
        print('Running time: %.0f min' % ((end - start) / 60))
        output_log.write('Running time: %.0f min' % ((end - start) / 60) + "\n")

        output_log.close()
        sys.exit()

    ### cluster enrichment
    """
     Fisher exact test

               cluster_nodes_path              non-cluster_nodes_path
         interest      a                                 b          num_interest_gene
     non-interest      c                                 d          num_non-interest_gene
                    num_path                num_non-cluster_nodes_path
   """
    ### read in gene list
    interest_listfile = open(Result_dir+"candidate.list", "r")
    interest_Genelist = []
    for line in interest_listfile.readlines():
        temp = line.split()
        interest_Genelist.append(temp[0])
    interest_listfile.close()

    cluster_nodes_path = expData + "/nodes_gene/"
    # dirs=os.listdir("../03_Data/Demo_ref/Demo_for_BEST/cluster_data/genelist/nodes_file/")
    dirs = os.listdir(cluster_nodes_path)
    dirs.sort(key=lambda x: int(x[9:-4]))
    #    print(dirs)

    ### READ IN CLUSTER LIST
    output = open(Result_dir+"temp_out", "w")
    output2 = open(Result_dir+"clustergenelist", "w")
    cluster_num = 0
    for nodefile in dirs:
        if os.path.splitext(nodefile)[1] == ".txt":  ### pick nodes file from all files under this directory
            cluster_listfilePath = os.path.join(cluster_nodes_path, nodefile)
            cluster_listfile = open(cluster_listfilePath, "r")
            ### read in genelist in each cluster
            cluster_Genelist = []
            for line in cluster_listfile.readlines():
                temp = line.split()
                cluster_Genelist.append(temp[0])
            cluster_num = cluster_num + 1  #
            ### get overlap gene
            for gene_item in list(set(interest_Genelist).intersection(set(cluster_Genelist))):
                output2.write(gene_item + "\t" + str(cluster_num) + "\t" + str(
                    os.path.splitext(nodefile)[-2]) + "\n")  ### for plotting manhattan figure

            ### fisher's exact calculation
            a = len(list(set(interest_Genelist).intersection(set(cluster_Genelist))))
            b = len(interest_Genelist) - a
            c = len(cluster_Genelist) - a
            d = 42525 - (a + b + c)
            #      print(a,b,c,d)
            oddsratio, pvalue = stats.fisher_exact([[a, b], [c, d]])
            output.write(str(os.path.splitext(nodefile)[0]) + "\t" + str(oddsratio) + "\t" + str(pvalue) + "\n")
    output.close()
    output2.close()
    multipletestingP(Result_dir+"temp_out", 2, cPvalCor, clusterPcut, Result_dir+"clusteringP_adjusted")
    cmd = "awk '{if($3<" + str(clusterPcut) + " && $2>1.0) print}' "+Result_dir+"temp_out > "+Result_dir+"enrichment_module.list"
    subprocess.call(cmd, shell=True)
    cmd="paste "+Result_dir+"temp_out "+Result_dir+"clusteringP_adjusted ' > "+Result_dir+"enrichment_module_adjusted.list.orig",
    subprocess.call(cmd, shell=True)
    cmd="paste "+Result_dir+"temp_out "+Result_dir+"clusteringP_adjusted | awk '{if($2>1.0) print}' | grep ' True ' > "+Result_dir+"enrichment_module_adjusted.list",
    subprocess.call(cmd, shell=True)

    cmd="awk '{print $1, $2==\"False\"?\"1.0\":$3}' "+Result_dir+"clusteringP_adjusted > "+Result_dir+"enrichment_module_adjusted.plot"
    subprocess.call(cmd, shell=True)

    cmd="Rscript /home/best-2/application/manhattan_bar.R "+Result_dir+"enrichment_module_adjusted.plot "+Result_dir+"manhattan_bar.pdf "+Result_dir+"manhattan_bar.png"
    subprocess.call(cmd, shell=True)

    f1 = open(Result_dir+"enrichment_module_adjusted.list", "r")
    for line in f1.readlines():
        temp = line.split()
        clusterfigpng = temp[0] + ".txt.exp.png"
        clusterfigpdf = temp[0] + ".txt.exp.pdf"
        clusterfigdata = temp[0] + ".txt.expression"
        cmd = "cp " + expData + "/" + clusterfigpdf + " "+Result_dir
        subprocess.call(cmd, shell=True)
        cmd = "cp " + expData + "/" + clusterfigpng + " "+Result_dir
        subprocess.call(cmd, shell=True)
        cmd = "cp " + expData + "/" + clusterfigdata + " "+Result_dir
        subprocess.call(cmd, shell=True)

    print("-------------------------------------------------Enrichment done!----------------------------------------")
    output_log.write("-------------------------------------------------Enrichment done!----------------------------------------"+"\n")




   ### get network plot
    #    print(cluster_nodes_path)
#    c_filelist = open(Result_dir+"enrichment_module_adjusted.list", "r")
#    for line in c_filelist.readlines():
#        temp = line.split()
#        node = cluster_nodes_path + str(temp[0]) + ".txt"
#        edges = expData + "/edges_gene/E_" + str(temp[0][2:] + ".txt")
#        networkoutput = str(temp[0] + ".plot")
#        plotfilename = str(temp[0] + ".list")
#        #       plotoutput=str(temp[0]+".pdf")
#        network(Result_dir+"candidate.list", node, edges, Result_dir+networkoutput, Result_dir+plotfilename)
#        # cmd="Rscript network.R "+plotfilename+" "+networkoutput+" "+plotoutput
#    #        cmd="Rscript igraph_network_test.R "+plotfilename+" "+networkoutput+" "+plotoutput
#    #        subprocess.call(cmd, shell=True)
#    cmd="cat "+Result_dir+"N_*list > "+Result_dir+"enrich.cluster."+str(myparser.expDataSet)
#    subprocess.call(cmd, shell=True)
#    output_log.write("-------------------------------------------------networking done!----------------------------------------"+"\n")

    ### new network plot
    c_filelist = open(Result_dir + "enrichment_module_adjusted.list", "r")
    cluster_node=[]
    enrich_pval=[]
    for line in c_filelist.readlines():
        temp=line.split()
        temp_table=str(myparser.expDataSet)+"_"+JobID.replace('-','')
        table='dataset'+str(myparser.expDataSet)[4:]+"_E_"+str(temp[0][2:])
        node = cluster_nodes_path + str(temp[0]) + ".txt"
        networkoutput = str(temp[0] + ".plot")
        plotfilename = str(temp[0] + ".list")
        input_data=Result_dir+"candidate.list"
        network_1(input_data, node, Result_dir+plotfilename)
        db_test_clusterplot.search_enrich_intersection_update(Result_dir+plotfilename, temp_table, table, Result_dir+networkoutput)
        cluster_node.append(temp[0])
        enrich_pval.append(temp[5])

###################################################################################################################################################
    ###################################################################################################################################################
    ###################################################################################################################################################
    ###################################################################################################################################################

    top5_enrich_cluster=dict(zip(cluster_node,enrich_pval))
    dict = sorted(top5_enrich_cluster.items(), key=lambda d: d[1], reverse=True)
    for item, values in dict[:5]:
        temp_table1=str(myparser.expDataSet)+"_"+JobID.replace('-','')
        temp_table2=str(myparser.expDataSet)+"_"+JobID.replace('-','')+"_top20"
        network_table='dataset'+str(myparser.expDataSet)[4:]+"_E_"+str(item)[2:]
        count_table='dataset'+str(myparser.expDataSet)[4:]+"_E_"+str(item)[2:]+"_count"
        input_data = Result_dir + "candidate.list"
        db_test_clusterplot.search_top_20(input_data, temp_table1, temp_table2, count_table, network_table, Result_dir+item+".top20")

    cmd="cat "+Result_dir+"*top20 > "+Result_dir+"all.top20"
    subprocess.call(cmd, shell=True)

    ###################################################################################################################################################
    ###################################################################################################################################################
    ###################################################################################################################################################

    cmd="cat "+Result_dir+"N_*list > "+Result_dir+"enrich.cluster."+str(myparser.expDataSet)
    subprocess.call(cmd, shell=True)
    output_log.write("-------------------------------------------------networking done!----------------------------------------"+"\n")


    ##### manhattan fig prep
    if (inType == "SNPandP") or (inType == "GENEandP"):
        if os.path.getsize(Result_dir+"enrich.cluster."+str(myparser.expDataSet)):
            manhattan_prep(Result_dir+"candidate.list", Result_dir+"clustergenelist", Result_dir+"enrichment_module_adjusted.list", Result_dir+"cluster_gene_pval")
            ##### plot manhattan fig
#            subprocess.call("Rscript manhattan.R", shell=True)
#            cmd="Rscript manhattan.R "+"cluster_gene_pval "+"manhattan.pdf "+"manhattan.png"
            cmd="Rscript /home/best-2/application/manhattan.R "+Result_dir+"cluster_gene_pval "+Result_dir+"manhattan.pdf "+Result_dir+"manhattan.png"
            print(cmd)
            subprocess.call(cmd, shell=True)
            output_log.write("-------------------------------------------------Manhattan done!----------------------------------------"+"\n")
#    print("-------------------------------------------------Manhattan done!----------------------------------------")
    output_log.write("------------------------------------------Manhattan finished-----------------------------------------------"+"\n")

    ### cell-type enrichment
    #### read cell type data
    celltypePath = "/home/best-2/reference_data/cell_type_reference/Cell_type_gene_result"
    celltype_dirs = os.listdir(celltypePath)
    celltype_pval = []

    f = open(Result_dir+"enrichment_module_adjusted.list", "r")
    cluster_list = []
    ### get enrichment cluster name
    for line in f.readlines():
        temp = line.split()
        cluster_list.append(temp[0])
    f.close()
    for filelist in cluster_list:
        clusterfilePath = str(os.path.join(cluster_nodes_path, filelist)) + ".txt"
        clusterfile = open(clusterfilePath, "r")
        clustergenelist = []
        ## read in cluster data
        next(clusterfile)
        for line in clusterfile.readlines():
            temp = line.split()
            clustergenelist.append(temp[0])
        ## read in celltype data
        for celltype_filelist in celltype_dirs:
            if os.path.splitext(celltype_filelist)[1] == ".txt":
                celltypefilePath = os.path.join(celltypePath, celltype_filelist)
                celltypefile = open(celltypefilePath, "r")
                celltype_genelist = []
                next(celltypefile)
                for line in celltypefile.readlines():
                    temp = line.split()
                    celltype_genelist.append(str.upper(temp[1]))
                celltypefile.close()
                ## Fisher exact test
                a = len(list(set(celltype_genelist).intersection(set(clustergenelist))))
                b = len(clustergenelist) - a
                c = len(celltype_genelist) - a
                d = 42525 - (a + b + c)
                oddsratio, pvalue = stats.fisher_exact([[a, b], [c, d]])
                if oddsratio > 1.0:
                    celltype_pval.append(pvalue)
                else:
                    celltype_pval.append(1.0)
    celltype_pval = np.array(celltype_pval)
    celltype_pval = celltype_pval.reshape(len(cluster_list), 5)
    np.savetxt(Result_dir+'celltype', celltype_pval)
    ### plot
    cmd="Rscript /home/best-2/application/cell_heatmap2.R "+Result_dir+"celltype "+Result_dir+"celltype.pdf "+Result_dir+"celltype.png "+Result_dir+"enrichment_module_adjusted.list "+Result_dir+"celltype_withclustering.pdf "+Result_dir+"celltype_withclustering.png"
    subprocess.call(cmd, shell=True)

    ### read in gene set
    f=open(Result_dir+"candidate.list", "r")
    candidate_genelist=[]
    for line in f.readlines():
        temp=line.split()
        candidate_genelist.append(temp[0])
    f.close()

    celltype_pval = []
    for celltype_filelist in celltype_dirs:
        if os.path.splitext(celltype_filelist)[1] == ".txt":
            celltypefilePath = os.path.join(celltypePath, celltype_filelist)
            celltypefile = open(celltypefilePath, "r")
            celltype_genelist = []
            next(celltypefile)
            for line in celltypefile.readlines():
                temp=line.split()
                celltype_genelist.append(str.upper(temp[1]))

            a = len(list(set(celltype_genelist).intersection(set(candidate_genelist))))
            b = len(candidate_genelist) - a
            c = len(celltype_genelist) - a
            d = 42525 - (a + b + c)
            oddsratio, pvalue = stats.fisher_exact([[a, b], [c, d]])
            if oddsratio > 1.0:
                celltype_pval.append(pvalue)
            else:
                celltype_pval.append(1.0)

    celltype_pval = np.array(celltype_pval)
    celltype_pval = celltype_pval.reshape(1, 5)
    np.savetxt(Result_dir+'geneset_celltype', celltype_pval)
    ### plot
    cmd="Rscript /home/best-2/application/cell_heatmap3.R "+Result_dir+"geneset_celltype "+Result_dir+"geneset_celltype.pdf "+Result_dir+"geneset_celltype.png"
    subprocess.call(cmd, shell=True)

    cmd="mv "+Result_dir+"geneset_celltype* ../."
    subprocess.call(cmd, shell=True)
    print("-------------------------------------------------Celltype done!----------------------------------------")
    output_log.write("-------------------------------------------------Celltype done!----------------------------------------"+"\n")





    ### zipping results
    pack_file=str(myparser.expDataSet)+"_result.tar"
    test_tar(pack_file,"Results")
    output_log.write("packing results...done!"+"\n")
    end = time.time()
    ending_time = time.asctime()
    print('Starting time: ' + str(starting_time) + '\t' + str(time.strftime('%Z', time.localtime())) + "\n")
    output_log.write('Starting time: ' + str(starting_time) + '\t' + str(time.strftime('%Z', time.localtime())) + "\n")
    print('Finishing time: ' + str(ending_time) + '\t' + str(time.strftime('%Z', time.localtime())) + "\n")
    output_log.write('Finishing time: ' + str(ending_time) + '\t' + str(time.strftime('%Z', time.localtime())) + "\n")
    print('Running time: %.0f min' % ((end - start) / 60))
    output_log.write('Running time: %.0f min' % ((end - start) / 60)+"\n")
    
    output_log.close()
