import os
Results_path='/home/BEST/data/0d0607ec-07e8-11e9-830d/'
resultDict={}

print(Results_path)
tab2_list=[]

for root,dirs,files in os.walk(Results_path):
    for name in dirs:
        if name[:11] == "clusterdata":
            tab2_list.append(name)
            cluster_list=[]
            for root_1,dirs_1,files_1 in os.walk(root+name+"/Results/"):
                 for filename in files_1:
                     if filename[:2]=='N_' and filename[-3:]=='png':
                         cluster_list.append(filename[:-12])
                         cluster_list.append('.'+root_1[10:]+filename)
            resultDict[name]=cluster_list
resultDict['tab2']=tab2_list

print(tab2_list)
