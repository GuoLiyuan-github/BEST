# Title     : TODO
# Objective : TODO
# Created by: mengchen.pu
# Created on: 2018/11/1
# original cell_heatmap.R
library(pheatmap)
library(data.table)
library(Cairo)     ### for saving fig avoiding X11
library(ggplot2)
args<-commandArgs()

#test<-read.table(args[6], header=F, sep='\t', row.names=1)
test<-read.table(args[6], header=F, sep='\t')
if(args[9]=="data1") {
    bk = unique(c(seq(-4,8, length=100)))
} else if (args[9]=="data2") {
    bk = unique(c(seq(0,3, length=100)))
} else if (args[9]=="data3") {
    bk = unique(c(seq(1.7,3.2, length=100)))
} else if (args[9]=="data4") {
    bk = unique(c(seq(-5,5, length=100)))
} else if (args[9]=="data5") {
    bk = unique(c(seq(-0.8,8.8, length=100)))
} else if (args[9]=="data6") {
    bk = unique(c(seq(-5,5, length=100)))
} else if (args[9]=="data7") {
    bk = unique(c(seq(-4.5,9.5, length=100)))
} else if (args[9]=="data8") {
    bk = unique(c(seq(-5,5, length=100)))
} else if (args[9]=="data9") {
    bk = unique(c(seq(-4,9, length=100)))
} else if (args[9]=="data10") {
    bk = unique(c(seq(0.8,3.1, length=100)))
}

colname<-c("Early fetal","Mid-fetal","Late fetal","Neonatal and infancy","Early childhood","Middle and late childhood","Adolescence","Young adulthood","Middle adulthood")
rowname<-c("dorsolateral prefrontal cortex"
,"orbital frontal cortex"
,"ventrolateral prefrontal cortex"
,"primary motor cortex"
,"primary somatosensory cortex (area S1, areas 3,1,2)"
,"posteroventral (inferior) parietal cortex"
,"parietal neocortex"
,"primary auditory cortex (core)"
,"posterior (caudal) superior temporal cortex (area 22c)"
,"inferolateral temporal cortex (area TEv, area 20)"
,"temporal neocortex"
,"primary visual cortex (striate cortex, area V1/17)"
,"occipital neocortex"
,"hippocampus (hippocampal formation)"
,"amygdaloid complex"
,"striatum"
,"medial ganglionic eminence"
,"caudal ganglionic eminence"
,"lateral ganglionic eminence"
,"anterior (rostral) cingulate (medial prefrontal) cortex"
,"dorsal thalamus"
,"mediodorsal nucleus of thalamus"
,"cerebellum"
,"cerebellar cortex"
,"upper (rostral) rhombic lip")

pheatmap(breaks=bk, log2(test+0.05), cluster_rows=F, cluster_cols=F, show_colnames=T, labels_col=colname, labels_row=rowname, fontsize_col=10, fontsize_row=10, na_col="grey75", filename=args[7])
CairoPNG(file=args[8], width=1024, height=768)
pheatmap(breaks=bk, log2(test+0.05), cluster_rows=F, cluster_cols=F, show_colnames=T, labels_col=colname, labels_row=rowname, fontsize_col=15, fontsize_row=15, na_col="grey75")
#dev.off()
