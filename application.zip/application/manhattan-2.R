library("reshape")
library("plyr")
library("plantbreeding")
mydata<-read.table("cluster_gene_pval",header = TRUE,sep=",")
mydata$geneID<-as.character(mydata$geneID) #将SNP数据转换为字符型
mydata$chrID<-as.integer(mydata$chrID) #将CHR数据转换为整数型
mydata1<-na.omit(mydata) #删除缺失值
manhatton.plot(dataframe = mydata1, SNPname = "geneID", chromosome = "chrID",position = "position", pvcol = "pvalue",gapbp = 5,
color=c("lightgreen","skyblue2"), line1=3, line2=5) #绘制manhattan图，dataframe=mydata1表示输入的数据框为mydata1，SNPname="SNP"表示SNP名为mydata1的第一列"SNP",同理，chromosome,position和pvcol分别表示染色体、位置、P值，它们分别对应mydata1的"CHR","BP"和"P"列；gapbp=500表示染色体间的间隔为500，color=c("lightgreen","skyblue2")表示绘制颜色为浅绿和天空蓝；line1和line2分别为在y=3和y=5处绘制横线。
