import os

jobid='7d2abf80-04f1-11e9-84d1'
Results_path='../data/'+jobid+"/"
#if os.path.isfile(Results_path+"Result.tar"):
#    Downloadfile=Results_path+"Result.tar"
#    print(Downloadfile)
#else:
#    Downloadfile=Results_path+"/error"
#    print("22222222222222")
#resultDic={'Download':Downloadfile}
resultDic={}
#tab1_list=[]
#for root,dirs,files in os.walk(Results_path):
#    print('1111')
#    for name in dirs:
#        if name[:11] == "clusterdata":
#            print(dirs)
#            print(root)
#            print(files)
#            expression_data=root+name+"/Results/expression.png"
#            celltype_data=root+name+"/Results/celltype.png"
#
#            if os.path.isfile(expression_data):
#                tab1_list.append(name+" expression data")
#                tab1_list.append(expression_data)
#
#            if os.path.isfile(celltype_data):
#                tab1_list.append(name+" celltype")
#                tab1_list.append(celltype_data)
#
#resultDic['tab1']=tab1_list

tab2_list=[]
for root,dirs,files in os.walk(Results_path):
    print(root)
    print(dirs)
    for name in dirs:
        if name[:11] == "clusterdata":
            print("11111111111          "+name)
            tab2_list.append(name)
            cluster_list=[]
            for root_1,dirs_1,files_1 in os.walk(root+name+"/Results/"):
                 for filename in files_1:
                     if filename[:2]=='N_' and filename[-3:]=='png': 
                         cluster_list.append(filename[:-12])
                         cluster_list.append(root_1+filename)
            resultDic[name]=cluster_list
resultDic['tab2']=tab2_list

print(tab2_list)

#tab3_list=[]
#for root,dirs,files in os.walk(Results_path):
#    for name in dirs:
#        if name[:11] == "clusterdata":
#            tab2_list.append(name)
#            cluster_list=[]
#            for root_1,dirs_1,files_1 in os.walk(root+name+"/Results/"):
#                 for filename in files_1:
#                     if filename[:2]=='N_' and filename[-4:]=='plot': 
#                         cluster_list.append(filename[:-5])
#                         cluster_list.append(root_1+filename)
#            resultDic[name]=cluster_list
#resultDic['tab3']=tab3_list
#
#tab4_list=[]
#for root,dirs,files in os.walk(Results_path):
#    for name in dirs:
#        if name[:11] == "clusterdata":
#            print(dirs)
#            print(root)
#            print(files)
#            man_data=root+name+"/Results/manhattan.png"
#            print(man_data)
#            if os.path.isfile(man_data):
#                tab4_list.append(name+" manhattan data")
#                tab4_list.append(man_data)

#resultDic['tab4']=tab4_list

#print(resultDic)
