# -*- coding: utf-8 -*-

### LOAD MODULES
from collections import Counter
import pymysql
import os

def couting(input, output):
    f=open(input, "r")
    geneID=[]
    next(f)
    for line in f.readlines():
        temp=line.split()
        geneID.append(temp[0])
        geneID.append(temp[1])
    f.close()

    a=Counter(geneID)
    print(a)

    f=open(output, "w")
    for item, values in Counter(geneID).items():
        print(item)
        print(values)
        f.write(str(item)+" "+str(values)+"\n")
    f.close()
    return

def create_db(inputfile, table_name):
    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db", local_infile=1)
    cursor=database.cursor()

    sql_comm1="create table "+table_name+" like temp_gene_linkcount;"
    sql_comm2="load data local infile '"+inputfile+"' into table "+table_name+" FIELDS terminated by ' 'lines terminated by'\\n';"
    try:
        cursor.execute(sql_comm1)
        database.commit()
        cursor.execute(sql_comm2)
        database.commit()
    except pymysql.Error as e:
        print(e)
        database.rollback()
    cursor.close()
    database.close()
    return

def delete_db(table_name):
    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db",local_infile=1)
    cursor = database.cursor()
    sql_comm='drop table '+table_name+';'
    try:
        cursor.execute(sql_comm)
        database.commit()
    except pymysql.Error as e:
        database.rollback()
        print(e)
    cursor.close()
    database.close()
    return

if __name__=="__main__":
#    dataset_list=["Study_one_cluster_result","Study_two_cluster_result","Study_three_cluster_result","Study_five_cluster_result","Study_seven_cluster_result"]
    dataset_list=["Study_two_refine","Study_one_refine"]
    for datasetID in dataset_list:
        print(datasetID)
        if datasetID=="Study_one_cluster_result":
            table_1="dataset1"
        elif datasetID=="Study_two_cluster_result":
            table_1="dataset2"
        elif datasetID=="Study_three_cluster_result":
            table_1="dataset3"
        elif datasetID=="Study_five_cluster_result":
            table_1="dataset5"
        elif datasetID=="Study_seven_cluster_result":
            table_1="dataset7"
        elif datasetID=="Study_one_refine":
            table_1="dataset9"
        elif datasetID=="Study_two_refine":
            table_1="dataset10"
        directory="/home/best-2/reference_data/cluster_reference/"+datasetID+"/edges_gene/"
        location=os.listdir(directory)
        print(location)
        for edgesfiles in location:
            if os.path.splitext(edgesfiles)[1]==".txt":
                input_cluster=os.path.join(directory,edgesfiles)
                output_cluster=os.path.join(directory,edgesfiles+".count")
                couting(input_cluster, output_cluster)
                table_name= table_1+"_"+edgesfiles[:-4]+"_"+"count"
                create_db(output_cluster, table_name)
#                delete_db(table_name)
