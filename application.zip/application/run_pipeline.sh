#!/usr/bin/bash
# parameters:
# transform inputstring to SNP file
# db_search.py inputpath and outputpath

echo "$1"  # inputdata
echo "$2"  # working dir
echo "$3"  # number of expression data sets
echo "$4"  # expression data set list
echo "$5"  # jobID
echo "$6"  # input Type
echo "$7"  # log P
echo "$8"  # LD_data
echo "SNP $9"  # SNPwindows
echo "genePcut ${10} "    # gene Pval cutoff
echo "geneCor ${11}"      # gene multi-test correction function
echo "clusterPcut ${12} "    # cluster enrichment Pval cutoff
echo "clusterCor ${13}"      # cluster enrichment multi-test correction function
echo "----------------------------------------"

python3.6 /home/best-2/application/db_search.py -i $1 -p $2 -s $9

expressiondata=$4
expArray=(${expressiondata//,/ })
for expData in ${expArray[@]}
do
    echo $expData
    mkdir -p /home/best-2/data/$5/cluster$expData
    python3.6 /home/best-2/application/pipeline_v8.py -input $1 -inType $6 -logP $7 -LDref $8 -upSNPmapping $9 -expData $expData -gPcut ${10} -gPvalCor ${11} -cPcut ${12} -cPvalCor ${13} -jobID $5 &
done

wait

python3.6 /home/best-2/application/plot_prep.py -id $5

#wait

# packing all results
if [ "$6" == "SNPandP" -o "$6" == "GENEandP" ]; then
    cp /home/best-2/data/$5/cluster$expData/Results/Gene_set  /home/best-2/data/$5/Gene_set.txt
elif [ "$6" == "SNPList" -o "$6" == "GeneList" ]; then
    awk '{print $1}' /home/best-2/data/$5/cluster$expData/Results/Gene_set > /home/best-2/data/$5/Gene_set.txt
fi

cp /home/best-2/demo_data/Readme.txt /home/best-2/data/$5/Readme.txt

python3.6 /home/best-2/application/packing.py $5
#tar -C /home/best-2/data/$5 -cvf /home/best-2/data/$5/all_result.tar cluster*/*tar enrich.png geneset_celltype.png geneset_celltype.pdf geneset_celltype
###btar -C /home/best-2/data/dd55f618-2080-11e9-b36c/ -rf /home/best-2/data/dd55f618-2080-11e9-b36c/all_result.tar geneset_celltype
python3.6 /home/best-2/application/db_update.py -i $5 -s finished -e good

echo "job finished!"
#x=1
#while [ $x -le $3 ]
#do
#    echo "111"
#    x=$(($x+1))
#done
#
#python3.6 /home/best-2/application/pipeline_v6.py -input $1 -inType SNPandP -logP no -LDref eur -upSNPmapping 5 -expData 1 -gPcut 0.01 -gPvalCor bonferroni -cPcut 0.01 -cPvalCor fdr_bh -jobID $5

#expData_Num=$3
#echo "$expData_Num"

#mkdir -p cluster1
#mkdir -p cluster3
#
#python3.6 -u pipeline_v3.py -input SNPandP -inType SNPandP -logP no -LDref eur -upSNPmapping 5 -expData 1 -gPcut 0.01 -gPvalCor bonferroni -cPcut 0.01 -cPvalCor fdr_bh -dir /Bioinfo/MDDRD2/PMO/pumc/project/BESTproject/Pipeline_v2/cluster1 &

#python3.6 -u pipeline_v3.py -input SNPandP -inType SNPandP -logP no -LDref eur -upSNPmapping 5 -expData 3 -gPcut 0.01 -gPvalCor bonferroni -cPcut 0.01 -cPvalCor fdr_bh -dir /Bioinfo/MDDRD2/PMO/pumc/project/BESTproject/Pipeline_v2/cluster3 &

