import pymysql
import argparse

def update_sql(jobid: object, status: object, error: object) -> object:
    """

    :rtype: object
    """
    database=pymysql.connect(host="localhost", port=3306,user="best",passwd="best@mysql", db="best_db")
    cursor=database.cursor()
    sql="UPDATE job_log_update SET modified_time=now(), Status='"+status+"', errorMessages='"+error+"' WHERE jobID='"+jobid+"'"
    try:
        cursor.execute(sql)
        database.commit()
    except:
        database.rollback()
        print("database update error!")
    cursor.close()
    database.close()
    return

if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--id", help="jobid")
    parser.add_argument("-s", "--status", help="job status")
    parser.add_argument("-e", "--error", help="job error messages")
    args=parser.parse_args()

    update_sql(args.id, args.status, args.error)
