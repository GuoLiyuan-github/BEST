import json

def test_json():

    return json.dump({})