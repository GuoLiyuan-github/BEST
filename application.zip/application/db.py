#
import pymysql
import uuid

print(str(uuid.uuid1()))

def insert_sql(jobname, jobid, inType, logP, expData, genePcut, gPvalCor, clusterPcut, cPvalCor, email, status, error):
    database=pymysql.connect(host="localhost", port=3306,user="best",passwd="best@mysql", db="best_db")
    cursor=database.cursor()
    sql="insert into job_log_update (timeDate, jobName, jobID, jobDir, inputType ,logP, expressionDataSet, genePcut, gAdjustedMethod, cEnrichPcut, cAdjustedMethod, emailAddr, status, errorMessages) values (now(), '"+jobname+"', '"+jobid+"', '/home/BEST/data/"+jobid+"', '"+inType+"', '"+logP+"', '"+expData+"', '"+genePcut+"', '"+gPvalCor+"', '"+clusterPcut+"', '"+cPvalCor+"', '"+email+"', '"+status+"', '"+error+"');"
    try:
        cursor.execute(sql)
        database.commit()
    except:
        database.rollback()
        print("database insert error!")
    cursor.close()
    database.close()
    return

def update_sql(jobid: object, status: object, error: object) -> object:
    """

    :rtype: object
    """
    database=pymysql.connect(host="localhost", port=3306,user="best",passwd="best@mysql", db="best_db")
    cursor=database.cursor()
    sql="UPDATE job_log_update SET Status='"+status+"', errorMessages='"+error+"' WHERE jobID='"+jobid+"'"
    try:
        cursor.execute(sql)
        database.commit()
    except:
        database.rollback()
        print("database update error!")
    cursor.close()
    database.close()
    return

def parameter_check(jobid):
    database = pymysql.connect(host="localhost", port=3306, user="best", passwd="best@mysql", db="best_db")
    cursor = database.cursor()
    sql = "UPDATE job_log_update SET Status='" + status + "', errorMessages='" + error + "' WHERE jobID='" + jobid + "'"
    try:

    except:
        database.rollback()
        print("database searching error!")
    cursor.close()
    database.close()
    return

if __name__=="__main__":
    database=pymysql.connect(host="localhost", port=3306,user="best",passwd="best@mysql", db="best_db")
    cursor=database.cursor()
#
    jobid=str(uuid.uuid1())
    jobname="abcde"
    jobDir="/home/BEST"
    inType="SNPandP"
    logP="yes"
    expData="1"
    genePcut=str(0.01)
    gPvalCor="fdr_bh"
    clusterPcut=str(0.01)
    cPvalCor="fdr_bh"
    email="test@dumb.com"
    status="running"
    error="Null"
    insert_sql(jobname, jobid, inType, logP, expData, genePcut, gPvalCor, clusterPcut, cPvalCor, email, status, error)
    update_sql(jobid, "finish", "gooood!")

    cursor.close()
    database.close()
