#!/usr/bin/env python
#-*- coding:utf8 -*-
# Power by yunkai.wang@oumeng.com.cn 2019-01-07 15:25:51

import json
import sys


"""
var ele = { "elements": {
        nodes: [
        {data: {id: '172', name: 'Tom Cruise', label: 'Person'}},
        {data: {id: '183', name: 'Top Gun', label: 'Movie'}}
        ],
        // edges: [{data: {source: '172', target: '183', relationship: 'Acted_In'}}]
        edges: [{data: {source: '172', target: '183', relationship: ''}}]
    },
} 
"""

def getJsonFile(infile,n=1):
    nodes = list()
    edges = list()
    nodesSet = set()
    with open(infile) as inf:
#	elementsDict = dict()
        elementsDict={}
        for line in inf:
            array = line.strip().split()
            if line.startswith('fromNode'):
                continue
            else:
                if array[0] + str(n) in nodesSet :
                    pass
                else:
                    nodesSet.add(array[0] + str(n))
                    nodes.append({"data": {"id": array[0]+str(n), "name":array[0]}})

                if array[1] + str(n) in nodesSet :
                    pass
                else:
                    nodesSet.add(array[1] + str(n))
                    nodes.append({"data": {"id": array[1]+str(n), "name":array[1]}})
                edges.append({"data": {"source": array[0]+str(n), "target": array[1] + str(n)}})
        elementsDict = {
                     "nodes": nodes,
                     "edges" : edges
                    }
    return elementsDict




#def getJsonFile(arrayFile):
   
#    for index,infile in enumerate(arrayFile.split(',')):
#        elementsDict = dict() 
#        parseText(infile,index)        

#    elementsDict = { 
#                     "nodes": nodes,
#                     "edges" : edges
#                    }
#    print(json.dumps(elementsDict))
#    json.dump(elementsDict,open(infile+"db","w"))
#    #return json.dumps(elementsDict)
#    return elementsDict

#getJsonFile(sys.argv[1])
